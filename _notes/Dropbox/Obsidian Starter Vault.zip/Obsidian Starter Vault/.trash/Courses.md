These are the course I've taken. Some, I've completed while others left in the middle. These notes include the highlights of the course I've taken. 

As I've already said, you might not understand a lot of these notes completely because they are not written for you. The are written to aid me in my thinking, remembering and getting the most out of these courses. 

However, I hope some of these notes might add value to your life.

- [[SEO That Works]]
- [[Productize Yourself]]
- [[Online Synthesizers]]
- [[SEO for Solopreneurs]]
- [[THE FUTURE SELF PROJECT]]
- [[How to Grow on Youtube]]
- [[Better Time Management]]
- [[Varasity Trading Course]]
- [[Month to Master Challange]]
- [[Write of Passage- David Perell]]
- [[How to visualize value- Design Fundamentals]]
- [[Complete Price Action Trading Complete Beginner to PRO(2021)]]