%%
ID: 13173163
Updated: 2022-01-27
%%
![](http://a2.mzstatic.com/us/r30/Publication/v4/9d/83/df/9d83df83-8c7f-f2f1-903c-eebd700c14a7/cover1400x0.jpeg)

# About
Title: [[The Four Agreements]]
Author: [[Don Miguel Ruiz]]
Category: #books
Number of Highlights: ==11==
Last Highlighted: *2022-01-27*
Readwise URL: https://readwise.io/bookreview/13173163

# Highlights 
THE TOLTEC WERE known throughout southern Mexico as “women and men of knowledge. ([1](https://readwise.io/to_kindle?action=open&asin=null&location=1)) ^277699456

---

Toltec knowledge arises from the same essential unity of truth as all the sacred esoteric traditions found around the world. ([2](https://readwise.io/to_kindle?action=open&asin=null&location=2)) ^277699554

---

He looked at the stars again, and he realized that it’s not the stars that create light, but rather light that creates the stars. ([3](https://readwise.io/to_kindle?action=open&asin=null&location=3)) ^277699590

---

although he was made of stars, he was not those stars ([4](https://readwise.io/to_kindle?action=open&asin=null&location=4)) ^277699604

---

Life is the force of the absolute, the supreme, the Creator who creates everything. ([5](https://readwise.io/to_kindle?action=open&asin=null&location=5)) ^277699761

---

He saw himself in everything — in every human, in every animal, in every tree, in the water, in the rain, in the clouds, in the earth. ([6](https://readwise.io/to_kindle?action=open&asin=null&location=6)) ^277699826

---

He tried to tell the others, but they could not understand ([7](https://readwise.io/to_kindle?action=open&asin=null&location=7)) ^277699942

---

They noticed that he no longer had judgment about anything or anyone. He was no longer like anyone else ([8](https://readwise.io/to_kindle?action=open&asin=null&location=8)) ^277699964

---

It is true. I am God. But you are also God. We are the same, you and I. We are images of light. We are God.” ([9](https://readwise.io/to_kindle?action=open&asin=null&location=9)) ^277700281

---

Living is easy with eyes closed, misunderstanding all you see….
— John Lennon ([10](https://readwise.io/to_kindle?action=open&asin=null&location=10)) ^277704856

---

You are dreaming with the brain awake. ([11](https://readwise.io/to_kindle?action=open&asin=null&location=11)) ^277705529

