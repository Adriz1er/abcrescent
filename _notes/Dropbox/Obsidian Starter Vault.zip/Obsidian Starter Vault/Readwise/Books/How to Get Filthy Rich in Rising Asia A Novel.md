# How to Get Filthy Rich in Rising Asia: A Novel

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/default-book-icon-6.71d9a01814f7.png)
[[ReadWise]]
## Metadata
- Author: [[Mohsin Hamid]]
- Full Title: How to Get Filthy Rich in Rising Asia: A Novel
- Category: #books

## Highlights
- You read a self-help book so someone who isn’t yourself can help you, that someone being the author
- None of the foregoing means self-help books are useless. On the contrary, they can be useful indeed
- This book is a self-help book. Its objective, as it says on the cover, is to show you how to get filthy rich in rising Asia.
- And to do that it has to find you, huddled, shivering, on the packed earth under your mother’s cot one cold, dewy morning
- In the city ten thousand makes you a poor man.”
