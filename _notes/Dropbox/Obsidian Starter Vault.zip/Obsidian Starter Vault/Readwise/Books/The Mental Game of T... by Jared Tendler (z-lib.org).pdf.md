# The Mental Game of T... by Jared Tendler (z-lib.org).pdf

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/default-book-icon-9.63dbe834380e.png)

## Metadata
- Author: [[Jared Tendler, M.S.]]
- Full Title: The Mental Game of T... by Jared Tendler (z-lib.org).pdf
- Category: #books

## Highlights
- lose money when you shouldn’t, or even if you consistently make money,
  you leave pro ts on the table. e question is why.
  For the answer, you’ll most likely look at your t
- your mental game, and you’re
  not e ectively working on it.
  at’s not to say trading is all about psych
- perfect mental game—emotionally balanced, always focused,
  consistently in the zone—won’t make you pro table long term if you
  don’t have an edge in the market. But if you have an edge, yet aren’t
  making what you should, or are struggling with greed, fear, anger,
  con dence or discipline, your mental game may be costing you more
  than you realize.
  ink about y
- answer
  doesn’t lie in what you know about trading. e answer comes from the
  mental and emotional side of the game—your mental game, and you’re
  not e ectively working on it.
  at’s not to say tradi
