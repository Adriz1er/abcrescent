%%
ID: 13205060
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[What Would You Do if You Don’t Know Your Life Purpose]]
Author: [[Dipanshu Rawal]]
Category: #articles
Number of Highlights: ==3==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205060
Source URL: https://medium.com/p/8a93573dda86


# Highlights 
Tying yourself to one life purpose and one goal sounds scary  ^278321618

---

Reading more books will open up your mind to more possibilities.  ^278321619

---

Be self-aware of who you are, your core values, standards, expectations, etc.  ^278321620

