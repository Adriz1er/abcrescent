%%
ID: 13205072
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

# About
Title: [[If You Want to Be Extraordinary, Spend Less Time on Your Phone]]
Author: [[Eva Keiffenheim]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205072
Source URL: https://medium.com/p/c4ea8c67dc0a


# Highlights 
Waking up to your smartphone alarm  ^278321643

