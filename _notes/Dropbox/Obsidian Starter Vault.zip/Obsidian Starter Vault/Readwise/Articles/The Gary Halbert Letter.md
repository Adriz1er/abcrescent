# The Gary Halbert Letter
#done 
![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[thegaryhalbertletter.com]]
- Full Title: The Gary Halbert Letter
- Category: #articles
- URL: https://thegaryhalbertletter.com/Boron/BoronLetterCh1.htm

## Highlights
- Take care of important things first and early before you lose the chance.
- Once the world wakes up and the e-mail messages, text messages and phone calls start your time will quickly get consumed with things that are urgent.
- If you take the time to think about it, everything you do in Q2 helps avoid having to do so much in Q1.
- At the end of the letter he talks about getting it done early because he knows that it is something that falls into Q2
- the second attempt at anything hard will be much easier. Not a little bit but by A LOT. It is true of almost everything, not just sports.
- Everyone wants to climb the mountain, but the big difference between those at the top and those still on the bottom is simply a matter of showing up tomorrow to give it just one more shot.
- We all love the high or endorphin rush we get from exercising for a long time and we all love that calm mellow glow we have when we are done, but I don’t look forward to the process of getting to that point.
- exercise should be fun from the get go and not a WORK out simply because if it is fun and therefore easier to find the motivation to do it and keep doing it.
- If you spend a lot of time working out you should spend less time at the doctor’s office.
- I prefer non-competitive sports instead
- Everything you do can be categorized as either important or not important. Also everything you do can be categorized as urgent or not urgent.
- If I had to guess, I’d say 90% of all successful people get up early and most of the other ten percent stay up late for the same reason. While everyone sleeps or watches the boob tube they can get stuff done without being interrupted.
- All first attempts are sloppy and lame.
- Anyone who ever learned to ride a bike remembers their first attempt to learn because it ended with blood. Oops, anyone old enough not to have the advantage of today’s protective gear that is.
- The moral of my dad’s workout story and mine is the same and it applies to all of life. Try things at least twice.
- Winners in life and successful people spend a lot more time doing things that fall into Q2 than most people.
- we all have to deal with what is important and urgent. However, early in the morning is the only time most of us can avoid dealing with regular chores long enough to take care of things categorized in Q2.
