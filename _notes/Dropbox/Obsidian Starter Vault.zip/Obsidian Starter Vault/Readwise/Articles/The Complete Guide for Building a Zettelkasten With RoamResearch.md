%%
ID: 13205087
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[The Complete Guide for Building a Zettelkasten With RoamResearch]]
Author: [[Eva Keiffenheim]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205087
Source URL: https://medium.com/p/8b9b76598df0


# Highlights 
The Zettelkasten becomes more useful as it grows because you can discover related ideas you hadn’t thought of in the first place  ^278321665

