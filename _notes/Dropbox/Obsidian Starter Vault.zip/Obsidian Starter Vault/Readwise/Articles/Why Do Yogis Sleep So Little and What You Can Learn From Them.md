%%
ID: 13205090
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

# About
Title: [[Why Do Yogis Sleep So Little and What You Can Learn From Them]]
Author: [[Shivendra Misra]]
Category: #articles
Number of Highlights: ==2==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205090
Source URL: https://medium.com/p/3f6f1c9ffee3


# Highlights 
When you’re walking, don’t be tensed thinking about how many calories you’re burning or how fast you’re walking. When you’re working, don’t think about how long it’s taking to complete the task or how the deadline hangs over your head.  ^278321668

---

yogis have a mission in life for which they want to stay awake. This strong desire helps them not fall into the trap of sleeping more than they need to.  ^278321669

