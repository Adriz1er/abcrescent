%%
ID: 13205081
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[A 117-Year-Old Woman Will Teach You to Be Young Again]]
Author: [[Tim Denning]]
Category: #articles
Number of Highlights: ==2==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205081
Source URL: https://medium.com/p/8f9574bb0009


# Highlights 
Have hope.  ^278321652

---

Phones ruin relationships. Board games enlarge your curiosity.  ^278321653

