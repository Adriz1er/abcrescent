# I Had an Existential Crisis!

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Kyle Kowalski]]
- Full Title: I Had an Existential Crisis!
- Category: #articles
- URL: https://www.sloww.co/existential-crisis/

## Highlights
- existential crisis can be a dark time. But the light on the other side is so worth going through it.
- view your existential crisis as something that’s wrong with you.
