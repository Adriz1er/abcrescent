%%
ID: 13204920
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

# About
Title: [[Making Notes From Your Reading Is Increasing Your Knowledge.]]
Author: [[Anders (Andy) Sporring]]
Category: #articles
Number of Highlights: ==12==
Last Highlighted: *2021-12-14*
Readwise URL: https://readwise.io/bookreview/13204920
Source URL: https://medium.com/taking-notes/making-notes-from-your-reading-is-increasing-your-knowledge-4b0402e06e81


# Highlights 
Notetaking is citing almost word for word what you read.  ^278319420

---

Notemaking is writing in your own words what you have read  ^278319421

---

But as the saying is: So little time, so much to learn. I use my digital tools mostly while notemaking, and of course, my shakings is still a limitation while taking notes by hand.  ^278319422

---

my approach to learning and building my knowledge is with the same hunger as a child, finally understanding how to read.  ^278319423

---

learning by doing is a great way to make some knowledge stick. Spaced repetition is also a great way to supercharge your learning, especially if you’re studying for an exam.  ^278319424

---

Using your own words and making your own connections makes the knowledge deepen. And the possibility of recreating that knowledge to your own content using your creativity skyrocket  ^278319425

---

Step one  ^278319426

---

Phrase the original text in your own words: Never use the original wording. Write it down in your own words and language. It also makes it easier to remember and avoid potential plagiarism when reworking the material for your content.  ^278319427

---

Step Two  ^278319428

---

Connecting the material/ideas:  ^278319429

---

Step Three  ^278319430

---

the more active you are in your notemaking, the more your knowledge increases.  ^278319431

