%%
ID: 13204959
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[The Creative Hack I Sadly Don’t See Many Creators Using]]
Author: [[Niharikaa Kaur Sodhi]]
Category: #articles
Number of Highlights: ==14==
Last Highlighted: *2021-11-25*
Readwise URL: https://readwise.io/bookreview/13204959
Source URL: https://medium.com/swlh/the-creative-hack-i-sadly-dont-see-many-creators-using-2b86d92d5c2a


# Highlights 
your work speaks only as loudly as you do.  ^278320193

---

Gone are the days when solely the quality of your content mattered  ^278320194

---

you could choose the traditional way and stay off social media and networking platforms. But here’s what you’ll miss out on — a global audience and clientele.  ^278320195

---

Creating quality work is a waste if you’re not making noise around your work and your personal brand.  ^278320196

---

Not all ideas need to be good, but you just need to keep ideating, the practice matters  ^278320197

---

Write 10 ideas a day. I write ideas for 10 articles each day. I probably use only 1 or 2, but this gets my creativity muscle going.  ^278320198

---

When you like an idea, outline your content blueprint. Whether it's a YouTube video or an article, jot down what it’ll comprise. On the day of creating, the outline makes it less overwhelming and will help you finish your piece.  ^278320199

---

the art of content repurposing  ^278320200

---

you use existing content to create branches of new content  ^278320201

---

copy-paste those snippets to Hypefury to schedule them for the coming week  ^278320202

---

Sometimes when I tweet my thoughts, I turn them into articles. That’s another way to create a piece of content from another.  ^278320203

---

I’ve also done this pretty cool thing: I sometimes catch myself typing a really insightful reply to somebody, something that's quote-worthy. It then turns into a tweet.  ^278320204

---

Well, it’s simple:You are busyCreative space is important to think and createYou don’t need to reinvent an existing wheelIn simpler words, it's a smarter thing to do.You’re already building content, use that to build a brand, an audience, and your credibility  ^278320205

---

Work hard on one thing and work smart around the others. Automate as much as possible. Use your free time to create a groundbreaking one colossal piece. Repeat.  ^278320206

