%%
ID: 13204909
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[Live Like You Just Escaped]]
Author: [[jamesaltucher.com]]
Category: #articles
Number of Highlights: ==5==
Last Highlighted: *2021-12-20*
Readwise URL: https://readwise.io/bookreview/13204909
Source URL: https://jamesaltucher.com/blog/live-like-just-escaped/


# Highlights 
“I don’t know when I’m going to die,” he said. “But there is no cure. I don’t want to get into a relationship. Too much of a burden for her.”
We’d walk and talk for hours. I considered him my best friend. When I moved we never spoke again.  ^278319242

---

Live in a hole. Live in a gutter. Live with roaches.  ^278319243

---

Live with a sense of, “I escaped!”  ^278319244

---

Live with alcoholics and scumbags and prostitutes and drug dealers. Live with unrequited love.  ^278319245

---

Explore where you live. You’ll never live there again.  ^278319246

