%%
ID: 13205092
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[The Quiet Power of Boredom in Your Life]]
Author: [[Tim Denning]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205092
Source URL: https://medium.com/p/59faa859d5f4


# Highlights 
We’re addicted to dopamine activities  ^278321671

