%%
ID: 13205091
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[Reading 100 Books Per Year Doesn’t Make You Special]]
Author: [[Matt Lillywhite]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205091
Source URL: https://medium.com/p/4e0deb2a99ca


# Highlights 
The More You Read, The Smarter You Become.  ^278321670

