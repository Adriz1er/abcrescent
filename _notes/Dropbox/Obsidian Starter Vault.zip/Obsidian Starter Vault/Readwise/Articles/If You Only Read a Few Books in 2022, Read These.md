%%
ID: 13222793
Updated: 2022-02-02
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

# About
Title: [[If You Only Read a Few Books in 2022, Read These]]
Author: [[Ryan Holiday]]
Category: #articles
Number of Highlights: ==3==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13222793
Source URL: https://ryanholiday.medium.com/if-you-only-read-a-few-books-in-2022-read-these-bb40f4f9e2d3


# Highlights 
But 2021, like all years, reminds us that the same things keep happening, that world events continue on in their own unpredictable way and that in the end, we control very little but our own actions and opinions.  ^278699065

---

“I’m not saying that you have to be a reader to save your soul in the modern world,” he said. “I’m saying it helps.”  ^278699066

---

Books are an investment in yourself — investments that come in many forms: novels, nonfiction, how-to, poetry, classics, biographies.  ^278699067

