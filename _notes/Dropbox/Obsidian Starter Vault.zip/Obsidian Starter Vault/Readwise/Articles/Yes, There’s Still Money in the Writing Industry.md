%%
ID: 13205064
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

# About
Title: [[Yes, There’s Still Money in the Writing Industry]]
Author: [[Adrian Drew]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205064
Source URL: https://medium.com/p/a66e1da16844


# Highlights 
r  ^278321630

