%%
ID: 13204937
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[3 Realistic Ways to Do More Quality Work Using Less Time and Effort]]
Author: [[Darshak Rana]]
Category: #articles
Number of Highlights: ==19==
Last Highlighted: *2021-11-27*
Readwise URL: https://readwise.io/bookreview/13204937
Source URL: https://medium.com/candid-conversations/3-realistic-ways-to-do-more-quality-work-using-less-time-and-effort-861b9b2f6a10


# Highlights 
the problem isn’t the amount of information; it’s time we spend focused on them.  ^278319850

---

The constant distractions did make me feel productive in my thoughts while, in reality, they were mere time wasters because they didn’t allow me to stay focused on any one thing for an extended period.  ^278319851

---

tried lots of different things and wrote down what worked, which didn’t and why.Eventually, with trial and error, I found out ways to get quality work done with minimal effort and time. These strategies saved me extra hours to devote to self-care.  ^278319852

---

Plan for a week, instead of a day  ^278319853

---

. It all depends on what works best for your schedule, personality, and type of work.  ^278319854

---

If a task is bigger, I break it down into smaller chunks that can be done daily for five days instead of completing it in one go.  ^278319855

---

Planning for the week also accommodates unproductive days when you feel lazy, overwhelmed, and frustrated.  ^278319856

---

committing to only three tasks is the key to higher productivity  ^278319857

---

Flex your routine  ^278319858

---

If something needs to happen by a certain time or date, I’ll write it in my calendar instead of diving straight into it.  ^278319859

---

if you don’t write them down, you’ll never remember everything you need to accomplish in one day. Besides  ^278319860

---

it automatically becomes part of tomorrow’s plan no matter what time you’re done.  ^278319861

---

“One sign of an expert is consistency in performance — doing better on difficult tasks compared to easier ones.”  ^278319862

---

if you want to meet your deadline, you should put your phone away and let them know that you can’t talk right now  ^278319863

---

You’ll be more productive if you commit to only “one objective” whenever possible to avoid losing your focus.  ^278319864

---

When you do more than one thing at once, your brain uses up the energy with the harder task and distributes it to other tasks compensating for quality.  ^278319865

---

when you switch from one activity to another, it takes time for your mind to get back into a flow state again.  ^278319866

---

You should also avoid interruptions because they can become distractions that affect your concentration and productivity for hours  ^278319867

---

Plan for a week, instead of a dayFlex your routineSpend all of your energy on one task  ^278319868

