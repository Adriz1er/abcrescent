%%
ID: 13205061
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

# About
Title: [[5 Things I Did Differently to Have the Best Year of My Life So Far]]
Author: [[Dipanshu Rawal]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205061
Source URL: https://medium.com/p/3c662e6798e7


# Highlights 
how long will you keep treating your characteristics as your issues?”  ^278321621

