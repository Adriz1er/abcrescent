%%
ID: 13204945
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[Newsletter Swaps- A Powerful Way to Grow Your Audience]]
Author: [[Anangsha Alammyan]]
Category: #articles
Number of Highlights: ==7==
Last Highlighted: *2021-11-25*
Readwise URL: https://readwise.io/bookreview/13204945
Source URL: https://medium.com/swapstack-creator-content-hub/newsletter-swaps-a-powerful-way-to-grow-your-audience-f2e79cab0427


# Highlights 
It’s platform-independent and gives you a convenient way to directly talk to your most loyal readers.  ^278319969

---

one of the least talked-about ones is newsletter swaps  ^278319970

---

By performing a “swap,” your readers learn about another newsletter they might like, and vice versa.  ^278319971

---

smart strategy for building your email list.  ^278319972

---

Some writers worry that adding the links to another newsletter might dilute their audience, but if you consistently write valuable content, you don’t have to worry about your subscribers leaving you and following another writer  ^278319973

---

Readers always love new creators to follow, and if you recommend them writers they’ll love, you’re only building their trust in you.  ^278319974

---

swapping newsletters is a great way of connecting with like-minded creators and building your tribe where you can grow faster together  ^278319975

