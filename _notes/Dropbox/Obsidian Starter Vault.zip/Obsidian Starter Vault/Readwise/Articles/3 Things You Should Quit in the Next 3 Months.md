%%
ID: 13205070
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

# About
Title: [[3 Things You Should Quit in the Next 3 Months]]
Author: [[Sinem Günel]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205070
Source URL: https://medium.com/p/84c6e4c8147


# Highlights 
Nobody who’s content and mindful would ever leave mean comments or treat somebody poorly.  ^278321640

