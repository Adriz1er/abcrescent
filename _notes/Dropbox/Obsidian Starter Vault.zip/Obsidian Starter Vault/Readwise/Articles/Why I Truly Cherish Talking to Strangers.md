%%
ID: 13205076
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[Why I Truly Cherish Talking to Strangers]]
Author: [[Fatimah Alayafi]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205076
Source URL: https://medium.com/p/129edcc0dc68


# Highlights 
This happens through meeting people who appreciate the real you without any professional, academic, or social interest at stake.  ^278321647

