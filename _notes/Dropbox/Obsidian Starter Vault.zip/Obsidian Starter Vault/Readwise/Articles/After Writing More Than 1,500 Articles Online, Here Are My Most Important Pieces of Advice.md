%%
ID: 13204949
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[After Writing More Than 1,500 Articles Online, Here Are My Most Important Pieces of Advice]]
Author: [[Rocco Pendola]]
Category: #articles
Number of Highlights: ==15==
Last Highlighted: *2022-01-08*
Readwise URL: https://readwise.io/bookreview/13204949
Source URL: https://medium.com/swlh/after-writing-more-than-1-500-articles-online-here-are-my-most-important-pieces-of-advice-7270c7034add


# Highlights 
but we’ll settle on 1,500 for the sake of argument and efficiency  ^278320009

---

Find a niche — maybe two — and create a conversation around it  ^278320010

---

You’ll probably never own whatever space you decide to create in. The upside to this — you don’t have to.  ^278320011

---

Select a space where most, if not all of the following criteria apply:  ^278320012

---

You have personal experience in the area and the stories to tell that go along with it.  ^278320013

---

The space you choose to create in is part of your everyday lif  ^278320014

---

You can expand your core area into relevant and viable sub-spaces  ^278320015

---

You can create an ongoing conversation with readers.  ^278320016

---

Real experience beats top-down prescriptions.  ^278320017

---

You’ll be better off creating in an area where you have more than mere success and failure. We  ^278320018

---

When experience meets emotion and leads to strategy you have something real and actionable to put in front of the reader.  ^278320019

---

actionable advice as a person who has lived and thought long and hard about living.  ^278320020

---

Find a niche — maybe two — and create a conversation around it  ^278320021

---

You’ll probably never own whatever space you decide to create in. The upside to this — you don’t have to.  ^278320022

---

While some writers succeed as generalists — writing about anything and everything — my experience and the experiences of people I follow and admire tends to favor the following strategy.  ^278320023

