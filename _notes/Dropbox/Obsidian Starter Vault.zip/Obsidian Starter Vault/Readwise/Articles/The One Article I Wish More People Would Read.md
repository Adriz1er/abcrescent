%%
ID: 13204970
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

# About
Title: [[The One Article I Wish More People Would Read]]
Author: [[Michael Thompson]]
Category: #articles
Number of Highlights: ==7==
Last Highlighted: *2021-11-22*
Readwise URL: https://readwise.io/bookreview/13204970
Source URL: https://medium.com/simple-pub/this-one-article-demonstrates-exactly-what-the-internet-needs-8848f171d5e4


# Highlights 
we miss seeing real human experience stories in our feeds which immediately made me think about my friend  ^278320399

---

It’s not content creation.It’s writing.It’s art.  ^278320400

---

George has not only seen a lot. He’s learned a lot  ^278320401

---

he’s doing what he can with what he has to help the people around him.  ^278320402

---

Every day for the last few months my feed has been filled with toxic qualities of others, success stories of how to succeed on this platform, what’s wrong with this platform, and articles that are clearly aimed at gaming the system, or worse, hitting on the fears and insecurities of people to make a buck.  ^278320403

---

we should be telling our stories in an attempt to bring people together instead of writing stuff or clicking on stuff that creates a divide.  ^278320404

---

The world needs more people like George who buck individualism and prioritize sharing their art to build communities.The world needs more people who are willing to share their honest stories.  ^278320405

