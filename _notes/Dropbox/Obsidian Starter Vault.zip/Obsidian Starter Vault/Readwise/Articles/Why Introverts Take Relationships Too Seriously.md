%%
ID: 13205059
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[Why Introverts Take Relationships Too Seriously]]
Author: [[Nikhil Meshram]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205059
Source URL: https://medium.com/p/2306663278f5


# Highlights 
A relationship is a crucial phase in the life of every introvert and they take it very seriously.  ^278321617

