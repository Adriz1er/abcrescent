%%
ID: 13521414
Updated: 2022-02-17
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[The Ultimate Guide to Writing Online]]
Author: [[perell.com]]
Category: #articles
Number of Highlights: ==3==
Last Highlighted: *2022-02-09*
Readwise URL: https://readwise.io/bookreview/13521414
Source URL: https://perell.com/essay/the-ultimate-guide-to-writing-online/


# Highlights 
Content builds on itself. It multiplies and compounds.  ^285013426

---

It all starts with sharing ideas online.  ^285013427

---

Writing online is the fastest way to accelerate your career.



It’s the best way to learn faster, build your resume, and find peers and collaborators who can create job and business opportunities for you.  ^285013428

