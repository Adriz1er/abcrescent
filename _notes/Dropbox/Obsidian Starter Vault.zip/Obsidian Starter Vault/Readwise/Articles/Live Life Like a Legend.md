%%
ID: 13204910
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

# About
Title: [[Live Life Like a Legend]]
Author: [[jamesaltucher.com]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2021-12-20*
Readwise URL: https://readwise.io/bookreview/13204910
Source URL: https://jamesaltucher.com/blog/live-legend/


# Highlights 
One grandmaster said, “HE LIVED LIFE AS A LEGEND. Nobody can explain him. Nobody can understand him.”  ^278319247

