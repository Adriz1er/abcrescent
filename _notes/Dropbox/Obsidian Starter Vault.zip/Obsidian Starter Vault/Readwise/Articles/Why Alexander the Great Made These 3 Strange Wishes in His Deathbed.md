%%
ID: 13205084
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[Why Alexander the Great Made These 3 Strange Wishes in His Deathbed]]
Author: [[Prakash Joshi Pax]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205084
Source URL: https://medium.com/p/ed7712af985d


# Highlights 
Why Alexander The Great Made These 3 Strange Wishes In His Deathbed  ^278321662

