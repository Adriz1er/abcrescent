## New highlights added March 27, 2022 at 7:03 AM
- Brainwash yourself or get brainwashed
- It’s realizing what causes your mood to blow up
- You will shape our planet’s future and make it happen. Don’t let us down. Maintain your badassery.
  So much drama goes away when you live as an unf*ckwithable Genius.
- ended up realizing that if anyone makes me mad, they own me. So, I try to not get mad anymore — Mike Tyson
  Anger is addictive. It’s worse than p*rn or crack. Go on Twitter. Look at all the addicts hooked on anger. They can’t get enough.
- Anger is a way to give control of your brain over to others. The news has been doing it for years. They use anger to get your attention and drain your life.
  Don’t get mad at randoms. Just be silent.
- It’s not even saying no at all. It’s saying nothing. It’s silence.
- No one can mess with you if you keep your mouth shut and let them ruin their own future.
  Silence removes a heck of a lot of drama.
- Talking takes energy. It encourages feedback. Why say anything at all?
- It’s saying “heck no” to 99% of asks
- Every ‘ask’ occupies room in your brain. Read that again
- It’s not waiting until you’re ready, because, you know, you can get hit by a bus
  Too many of us will just wait forever — SteveOnSpeed
- Stuff that matters happens today. Stuff that doesn’t matter happens in the fantasy world of tomorrow — where a bus in the face can end your life
- It’s building a fortress around your mind
  A large pair of biceps doesn’t make you strong. Your mind does.
- You can build a fortress around your mind by studying psychology. Start with “Think And Grow Rich.” Then read some Carl Jung. Finish with “Influence: The Psychology of Persuasion.”
- Psychology helps decode your mind. Once you understand how you think, everything changes. You see excuses as lies, asks as hidden agendas, and the best skill to learn as gentle persuasion.
- It’s being a tightarse with your time
- Start saying no. Those pick your brain direct messages? Sorry, can’t do it. The podcast interview for the nice woman with 4 listeners and a free cup of instant coffee on arrival? Soz. No time.
- Treat every hour on Earth like one whole Bitcoin.
- You’ll never waste another minute fulfilling someone else’s agenda using your borrowed time. Time that could suddenly expire if a speed boat crashes into your bedroom at night and lands on your gorgeous face.
- It’s thinking fame and riches are a joke
- Life becomes a competition. Everyone is your enemy. You have to adopt the step-over-dead-bodies mindset. It’s disgusting, worse than Paris Hotel Hilton.
- Talk to a few famous people. I have. They’re desperate for a normal life.
- The worst part about fame? You lose your freedom of speech. Everything you say is subject to scrutiny. Tweets from 5 years ago can destroy everything you’ve built and cause the Lambo to get towed away forever.
- Wealth is NOT being famous.
  It’s owning your time to do whatever the hell you want and snoozing until 11 AM if you choose to lose a few hours of the day.
- The same sh*t you laugh at can happen to you
  Don’t look down on others. Why?
  One day it could happen to you. You see it with 20-30 year olds. They laugh at people with kids. They say “what a bad parent” when a kid screams louder than Mariah Carey on a vocal track.
  Then years later they end up being part of an accidental pregnancy. Now the joke is on them. Try getting a kid to be quiet for 5 minutes.
  Imagine everyone else’s problem as your future problem. It provides unf*ckwithable empathy.
# Here’s How to Become an Unf*ckwithable Genius - So You Can Remove 99% of the Drama From Life

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Tim Denning]]
- Full Title: Here’s How to Become an Unf*ckwithable Genius - So You Can Remove 99% of the Drama From Life
- Category: #articles
- URL: https://timdenning.com/heres-how-to-become-an-unfckwithable-genius-so-you-can-remove-99-of-the-drama-from-life/

## Highlights
- No matter what any dumb boss says, you can’t mess with her. She’ll show up, follow up, and blow up most debates.
- Brainwash yourself or get brainwashed
- It’s realizing what causes your mood to blow up
- You will shape our planet’s future and make it happen. Don’t let us down. Maintain your badassery.
  So much drama goes away when you live as an unf*ckwithable Genius.
- ended up realizing that if anyone makes me mad, they own me. So, I try to not get mad anymore — Mike Tyson
  Anger is addictive. It’s worse than p*rn or crack. Go on Twitter. Look at all the addicts hooked on anger. They can’t get enough.
- Anger is a way to give control of your brain over to others. The news has been doing it for years. They use anger to get your attention and drain your life.
  Don’t get mad at randoms. Just be silent.
- It’s not even saying no at all. It’s saying nothing. It’s silence.
- No one can mess with you if you keep your mouth shut and let them ruin their own future.
  Silence removes a heck of a lot of drama.
- Talking takes energy. It encourages feedback. Why say anything at all?
- It’s saying “heck no” to 99% of asks
- Every ‘ask’ occupies room in your brain. Read that again
- It’s not waiting until you’re ready, because, you know, you can get hit by a bus
  Too many of us will just wait forever — SteveOnSpeed
- Stuff that matters happens today. Stuff that doesn’t matter happens in the fantasy world of tomorrow — where a bus in the face can end your life
- It’s building a fortress around your mind
  A large pair of biceps doesn’t make you strong. Your mind does.
- You can build a fortress around your mind by studying psychology. Start with “Think And Grow Rich.” Then read some Carl Jung. Finish with “Influence: The Psychology of Persuasion.”
- Psychology helps decode your mind. Once you understand how you think, everything changes. You see excuses as lies, asks as hidden agendas, and the best skill to learn as gentle persuasion.
- It’s being a tightarse with your time
- Start saying no. Those pick your brain direct messages? Sorry, can’t do it. The podcast interview for the nice woman with 4 listeners and a free cup of instant coffee on arrival? Soz. No time.
- Treat every hour on Earth like one whole Bitcoin.
- You’ll never waste another minute fulfilling someone else’s agenda using your borrowed time. Time that could suddenly expire if a speed boat crashes into your bedroom at night and lands on your gorgeous face.
- It’s thinking fame and riches are a joke
- Life becomes a competition. Everyone is your enemy. You have to adopt the step-over-dead-bodies mindset. It’s disgusting, worse than Paris Hotel Hilton.
- Talk to a few famous people. I have. They’re desperate for a normal life.
- The worst part about fame? You lose your freedom of speech. Everything you say is subject to scrutiny. Tweets from 5 years ago can destroy everything you’ve built and cause the Lambo to get towed away forever.
- Wealth is NOT being famous.
  It’s owning your time to do whatever the hell you want and snoozing until 11 AM if you choose to lose a few hours of the day.
- The same sh*t you laugh at can happen to you
  Don’t look down on others. Why?
  One day it could happen to you. You see it with 20-30 year olds. They laugh at people with kids. They say “what a bad parent” when a kid screams louder than Mariah Carey on a vocal track.
  Then years later they end up being part of an accidental pregnancy. Now the joke is on them. Try getting a kid to be quiet for 5 minutes.
  Imagine everyone else’s problem as your future problem. It provides unf*ckwithable empathy.
