%%
ID: 13204961
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

# About
Title: [[Roam Research Alternatives]]
Author: [[travischan.medium.com]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2021-11-25*
Readwise URL: https://readwise.io/bookreview/13204961
Source URL: https://travischan.medium.com/roam-research-alternatives-42030ef3a087


# Highlights 
backlinks, block references, among other key features in the note-taking space  ^278320234

