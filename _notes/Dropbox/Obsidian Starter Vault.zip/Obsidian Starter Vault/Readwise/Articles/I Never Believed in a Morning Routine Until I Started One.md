%%
ID: 13205073
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[I Never Believed in a Morning Routine Until I Started One]]
Author: [[Shuana Yap]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205073
Source URL: https://medium.com/p/b672e2d35f92


# Highlights 
Please tell me I’m not the only person who reads and watches content like this…  ^278321644

