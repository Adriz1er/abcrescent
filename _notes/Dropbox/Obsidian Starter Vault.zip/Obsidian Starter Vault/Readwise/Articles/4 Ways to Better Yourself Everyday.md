%%
ID: 13205056
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

# About
Title: [[4 Ways to Better Yourself Everyday]]
Author: [[Maryam]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205056
Source URL: https://medium.com/p/7c17a7288c2b


# Highlights 
When diet is wrong, medicine is of no use. When diet is correct, medicine is of no need  ^278321612

