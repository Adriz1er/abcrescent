%%
ID: 13204988
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

# About
Title: [[How to Make New Friends as an Adult]]
Author: [[fastcompany.com]]
Category: #articles
Number of Highlights: ==10==
Last Highlighted: *2021-11-06*
Readwise URL: https://readwise.io/bookreview/13204988
Source URL: https://www.fastcompany.com/90674975/how-to-make-new-friends-as-an-adult-2


# Highlights 
you’ll see that you’re probably connected to a lot of people. But how many of those people are your friends  ^278320701

---

As you get into a routine of working, your social circle tends to shrink.  ^278320702

---

Make the timeOne of the difficulties  ^278320703

---

If you don’t devote any time to making and developing new friendships, you can’t be surprised that your circle of friends is small  ^278320704

---

If you’re not used to having a lot of friends any more, you may actually need to remind yourself to engage.  ^278320705

---

Engage common interests  ^278320706

---

nice to have people that will just listen to what you have to say, provide a little feedback, but mostly be there to validate your concerns.  ^278320707

---

Be willing to open up  ^278320708

---

In the end, you’re not just looking for people to hang out with. You need to take the leap to let a few of those people know more about who you are and to get to know them in turn  ^278320709

---

There is value in having friends you can be open with. The most central value is that it is easy to believe that you are the only one having the particular struggles, ambitions, or dreams you have  ^278320710

