# I Can’t Get Through Most Content — even by Great Writers.

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Sean Kernan]]
- Full Title: I Can’t Get Through Most Content — even by Great Writers.
- Category: #articles
- URL: https://medium.com/curious/i-cant-get-through-most-content-even-by-great-writers-d740faa8fd15

## Highlights
- The secret to improvement is my wet-blanket technique.
- What’s your best writing advice?”
- “Nobody gives a shit,” I said
- “No, seriously — take a look around the room right now.”
- Face to face, we nod and smile. We agree and say things like, “Oh yeah definitely! I tottttally agree.”
- Don’t presume you are much better. A few of you are already nodding off.
- The only difference between us and them? We are better at faking it.
- As soon as we are alone in our home, laying on the couch? The fucks leave the building.
- Readers are goldfish
- On the most important article you ever write, your most vulnerable, honest, well-polished piece — half your audience bails out to go look at silicone booty closeups on Instagram.
- If you were in the middle of a conversation or presentation — and half the people stood up, yawned, and walked away— you’d be pissed.
- People care about the children. They care about right and wrong. They pretend to care about social issues.And they only care about your content to the extent that it entertains them.A cynical view? Perhaps. But it’s the truth and you can use it to your advantage.
- You are either telling a killer story, giving unique, useful information that hasn’t been repeated 10 billion times already, or your readers are peacing out, “It’s curtains, baby.”
- the web is full of kumbaya-you-could-be-Shakespeare writing tips. I love positivity and giving writers hope. But they need to understand how jaded most people are with reality.
- Most people are on a desperate quest to avoid being bored.
- nobody gives a shit.So do something about it.
- How to create an article that people actually finish
- When you start writing, be open and free. Be a happy butterfly and chase yourself with your own net. Put the words on the page
- Then, do additional passes. Tweak things. Do more research. Make it tight.
- Your last round of edits should be done with your eyes squinted, with a cold wet blanket, draped over your head.
- Write for the most cynical reader in your audience.
- If you can win the most cynical reader over, you can win most of them over
- You don’t have much time. Neither do I. So make it damn good. Make sure your reader comes away feeling like their time was well spent.
- Talks Most, Says Least.Talks Least, Says Most.Which would you rather be? As a writer, the answer should be obvious.
- If you’ve made it this far, you’ve proven your attention span is better than your fellow monkeys. And for that, I applaud you.
