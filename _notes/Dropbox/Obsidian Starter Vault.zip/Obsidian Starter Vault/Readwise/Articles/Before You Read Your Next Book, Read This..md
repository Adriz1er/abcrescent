%%
ID: 13204951
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[Before You Read Your Next Book, Read This.]]
Author: [[Karan]]
Category: #articles
Number of Highlights: ==13==
Last Highlighted: *2021-11-26*
Readwise URL: https://readwise.io/bookreview/13204951
Source URL: https://medium.com/swlh/before-you-read-your-next-book-read-this-ee737d04b60c


# Highlights 
Then what makes you think that just reading a book is going to help you in any way?  ^278320040

---

was like, I was trying to make lemonade by just looking at the lemons  ^278320041

---

Books cost money and time and it’s better to read them the right way or not do it at all. By books, I mean only non-fiction  ^278320042

---

Your brain will probably not be able to process 100 pages at once let alone retain them.  ^278320043

---

You’ll be able to focus on other important things in life. Reading books alone does not guarantee success. You have to plan your goals, strategize, execute and achieve!  ^278320044

---

Most importantly, you will always enjoy your reading sessions!  ^278320045

---

don’t recommend dividing books based on chapters and topics because sometimes one chapter can be way lengthier/shorter than the other.  ^278320046

---

you don’t have to take notes immediately after finishing your reading session  ^278320047

---

Before you begin your next reading session, make sure you go through the previous day’s notes.  ^278320048

---

Publicity is more important than marketing for building a great brand. Publicity through press conferences, newspaper articles, TV interviews, magazine articles, etc. News Media wants to talk about What’s New, What’s Hot, What’s First, not What’s better. All the greatest companies ever were first created in the pages of The Wall Street Journal, Business Week, Forbes, Fortune, etc by Publicity, not by Advertising. Publicity is what gives birth to a brand.  ^278320049

---

Publicity through press conferences, newspaper articles, TV interviews, magazine articles, etc. is what gives birth to a brand.This way you will end up with a summary that you can read anytime you want. Moreover, the highlighted text will reduce the summary even more.  ^278320050

---

My book summaries are often 10–15-minute reads while the highlighted texts are usually 2–3 minute reads. Too short does not work.  ^278320051

---

Revisiting old notes is always fun!  ^278320052

