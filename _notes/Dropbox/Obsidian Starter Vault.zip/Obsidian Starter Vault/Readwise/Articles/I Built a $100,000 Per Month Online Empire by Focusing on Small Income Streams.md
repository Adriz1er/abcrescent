# I Built a $100,000 Per Month Online Empire by Focusing on Small Income Streams

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Abena Talks]]
- Full Title: I Built a $100,000 Per Month Online Empire by Focusing on Small Income Streams
- Category: #articles
- URL: https://intriguework.medium.com/i-built-a-100-000-per-month-online-empire-by-focusing-on-small-income-streams-6a1eb51e6e2a

## Highlights
- Everyone wants to make money online these days, don’t believe the hype, it won’t happen overnight. My overnight success took more than ten years and I’m only scratching the surface right now.
- Start small, build up.
- I believe in setting big goals but if you are new to the game, don’t destroy your self-confidence by setting a goal of $100,000 in your first month. Understand the system, learn, build and grow.
- You might get lucky but don’t rely on luck, rely on consistency, rely on strategy, planning and ACTION
