# Consistency Is the Currency of Success.

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Coach Tony]]
- Full Title: Consistency Is the Currency of Success.
- Category: #articles
- URL: https://betterhumans.pub/consistency-is-the-currency-of-success-9e2e9d7ac7c3

## Highlights
- #1. Tiny habits can get very, very big.
- One of the knocks on the phrase “tiny habits” is that they sound like they won’t get you anywhere.
- #2. Small dreams can also get very large.
- #3. Have fewer meetings.
- only taking high-value meetings. There are a lot of reasons, but one is just the wild, unchecked costs of pointless meetings. It’s easy to measure when you tally up salaries. But also just as costly in terms of productivity.
- Courage is the most important of all the virtues because without courage, you can’t practice any other virtue consistently. ~ Maya Angelou
# Consistency Is the Currency of Success.

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Coach Tony]]
- Full Title: Consistency Is the Currency of Success.
- Category: #articles
- URL: https://betterhumans.pub/consistency-is-the-currency-of-success-9e2e9d7ac7c3

## Highlights
- #1. Tiny habits can get very, very big.
- One of the knocks on the phrase “tiny habits” is that they sound like they won’t get you anywhere.
- #2. Small dreams can also get very large.
- #3. Have fewer meetings.
- only taking high-value meetings. There are a lot of reasons, but one is just the wild, unchecked costs of pointless meetings. It’s easy to measure when you tally up salaries. But also just as costly in terms of productivity.
- Courage is the most important of all the virtues because without courage, you can’t practice any other virtue consistently. ~ Maya Angelou
