# Having a Creative Block? — Read These 3 Books

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Shreya Badonia]]
- Full Title: Having a Creative Block? — Read These 3 Books
- Category: #articles
- URL: https://baos.pub/having-a-creative-block-read-these-3-books-4fd8dd137cc1

## Highlights
- The Artist’s Way: A Spiritual Path to Higher Creativity by Julia Cameron
- Steal Like An Artist by Austin Kleon
- The Dip by Seth Godin
- “The Dip is the long slog between starting and mastery. A long slog that’s actually a shortcut, because it gets you where you want to go faster than any other path.” — Seth Godin
