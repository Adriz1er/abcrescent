%%
ID: 13204979
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[Here’s Your Productivity Hack- Go the Fck to Sleep]]
Author: [[thoughtcatalog.com]]
Category: #articles
Number of Highlights: ==23==
Last Highlighted: *2021-11-14*
Readwise URL: https://readwise.io/bookreview/13204979
Source URL: https://thoughtcatalog.com/ryan-holiday/2015/07/heres-your-productivity-hack-go-the-fck-to-sleep/


# Highlights 
If you read a lot or are someone who gets a lot done, people will assume two things.  ^278320527

---

that you’re a speed reader. Two, that you never sleep.  ^278320528

---

There’s no trick to reading a lot. But more importantly, no one can skimp on sleep—not for long anyway.  ^278320529

---

sleep is the source of all health and energy.”  ^278320530

---

“Sleep when you’re dead,” we say. Like it’s some badge of honor how little time we allot to it.  ^278320531

---

The benefits minimal. And the claims are dishonest.  ^278320532

---

The human body needs its rest, it needs to replenish and burning it out is, as Schopenhauer said, a ridiculously short-sighted strategy.  ^278320533

---

Though the research says that for every 100 people who think they need minimal amounts of sleep, only 5-6 are scientifically able to do it without trading performance). But this is not the badge of honor they think.  ^278320534

---

didn’t need to–because I handled my shit and had my priorities straight.  ^278320535

---

Sleep is one of the most important parts of my work routine, period  ^278320536

---

This strategy not only hasn’t affected my output, it’s contributed crucially to my best work  ^278320537

---

they slept more than lesser players. But no one seems to want to say that. The only person speaking out for more sleep Arianna Huffington.  ^278320538

---

one of the most important concepts in economics is the law of diminishing returns.  ^278320539

---

Instead, we work with our minds. The clearer we can think and the better our mental and physical state—the better we will do  ^278320540

---

Meanwhile, idiots focus on marginal productivity hacks and gains while they leak out energy each passing day.  ^278320541

---

the longer you can stay at it the more you’ll make (t  ^278320542

---

This is insane, this is stupid, and anyone that would sign themselves up for this isn’t thinking.  ^278320543

---

the single best productivity secret was this: Waking up early. Because there were fewer distractions and you had quiet time yourself—you’re in control, not the busy world. He doesn’t say deprive yourself of sleep to accomplish it, of cours  ^278320544

---

It’s not performance that keeps them going, it’s just ego and stubbornness.  ^278320545

---

if you’re a security guard or a doorman or a factory worker or an Uber driver  ^278320546

---

You can burn yourself out in a few years for someone else at a high salary. OR, you can play the long game.  ^278320547

---

Conservation of energy. Never stand up when you can sit down, and never sit down when you can lie down.  ^278320548

---

when you can’t keep your eyes open, go to sleep. When you hit your limits, listen. The body is telling you something  ^278320549

