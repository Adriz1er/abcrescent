%%
ID: 13204968
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[Spend One Hour in November to Create a More Productive 2022]]
Authors: [[Michelle Loucadoux]], [[MBA]]
Category: #articles
Number of Highlights: ==15==
Last Highlighted: *2021-11-22*
Readwise URL: https://readwise.io/bookreview/13204968
Source URL: https://betterhumans.pub/spend-one-hour-in-november-to-create-a-more-productive-2022-860c463f1348


# Highlights 
Their inability to withstand temporary suffering in the short term for a larger reward in the futu  ^278320354

---

We continue to type in our credit card numbers every month instead of setting up automatic payment  ^278320355

---

we choose the “now” instead of the “future.”  ^278320356

---

Because, a bird in the hand is better than two in the bush. Right? turns out, not so much.  ^278320357

---

if we simply take some time to put a few things in motion, we can save huge amounts of time in the future.  ^278320358

---

So, let’s take advantage of it in 2022, shall we?  ^278320359

---

The fact is, most of us are not using the technology we have in the best way possible to benefit our personal productivity.  ^278320360

---

Automate all your payments  ^278320361

---

using a credit card that offers rewards. That way, you get huge benefits for simply paying  ^278320362

---

Schedule your “me time”  ^278320363

---

if you are rested and you feel like you have given yourself the time to recharge, you will be more productive in the long run.  ^278320364

---

it will make an epic difference in how you value yourself. And it will force you to take time for epically important down-time — something we all need to do.  ^278320365

---

Schedule your “normal” activities  ^278320366

---

You can schedule all of this. And, whether you stick to the schedule you create or you move your obligations around, the one thing you do by scheduling these things is . . . you free your brain for pondering more important issues  ^278320367

---

take time to set yourself up for success in 2022. Anything that you can do now that will alleviate stress, open up time, and free up creative brain space in the future is the bomb diggety best.  ^278320368

