%%
ID: 13204894
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[How I Make $1,000+ Every Month by Writing Online]]
Author: [[Christopher Kokoski]]
Category: #articles
Number of Highlights: ==17==
Last Highlighted: *2022-01-19*
Readwise URL: https://readwise.io/bookreview/13204894
Source URL: https://medium.com/the-bald-writer/how-i-make-1-000-every-month-by-writing-online-fd67fae6fc48


# Highlights 
Once you spot your money-makers, double down on that line of content.  ^278318994

---

The more articles you write each month, the faster you will reach the 1k mark. It took me three months.  ^278318995

---

consistently make $1,000 per month writing online.  ^278318996

---

Respond to 99% of Your Comments  ^278318997

---

Write 1–2 Articles Every Day  ^278318998

---

Always Publish With Your Top-Performing Platforms & Publications  ^278318999

---

Write 1–2 articles every day.Write articles about sex, true crime, writing, and relationships.Write 5–7 minute articles (approximately between 800 to 1,300 words).Write a good headline based on a successful template.Include a custom & relevant image at the top of every article.Track your best-performing tags. Add the maximum number of your top-performing tags to each article. Make sure they are relevant.Include an affiliate disclaimer and link at the bottom of every article.Track your best-performing platforms and publications. Always publish with your top-performers.Respond to 99% of your comments.Study your best-performing articles and write more on the same or similar topics.Make your articles as original and interesting as possible.  ^278319000

---

Consistently writing and publishing content is what ultimately separates those who make money writing online and those who don’t.  ^278319001

---

Not everyone has the tenacity, patience, or skill set to follow this system  ^278319002

---

Track where your articles make the most money and publish most (or all) of your articles there.  ^278319003

---

Study Your Best-Performing Articles and Write More of the Same  ^278319004

---

I almost didn’t write this article because part of me believes it is all very obvious. A little too obvious.  ^278319005

---

The two irrefutable rules of making money writing online is:To be helpfulTo not be boring  ^278319006

---

Make Your Articles as Original and Interesting as Possible  ^278319007

---

Sometimes, as writers, we write what we want or what we think we should write.  ^278319008

---

Everything should hook the reader — your title, subheadings, transitions, stories, images, everything.  ^278319009

---

By “original” I mean:New informationUnique words, stories, and perspectivesNothing simpleNothing obviousFirst-hand experience (or close to it)  ^278319010

