%%
ID: 13204911
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

# About
Title: [[Writing for Social Media- 7 Tips and Tools]]
Author: [[blog.hootsuite.com]]
Category: #articles
Number of Highlights: ==33==
Last Highlighted: *2021-12-28*
Readwise URL: https://readwise.io/bookreview/13204911
Source URL: https://blog.hootsuite.com/writing-for-social-media/


# Highlights 
7 writing tips for social media
…and for any kind of persuasive writing.  ^278319248

---

Suggestion: let loose, try some (or all) of these, and repeat them for a few of your posts. Build those new writing-muscles.  ^278319249

---

1. Barf it out  ^278319250

---

just keep your fingers typing, looking at the keyboard not the screen, so your brain engages. forget about sentence structure, spelling, punctuation… just keep your fingers moving and p[ower through any blockages.  ^278319251

---

just typw. editing will come later  ^278319252

---

It’s never write the first time. but push stuff that’s in your head onto the page, then mnake your 4 or 5 or 6 or 7 edits…. LATER.  ^278319253

---

Whenever, I’m ‘stuck’, for any kind of writing… I just type. Every time, something useful appears before my writing-eyes-and-brain.  ^278319254

---

Punch the so-called “writer’s block” right in the gut. It’s bunk.  ^278319255

---

2. Write to an 8th grader  ^278319256

---

Not because they aren’t smart. Because it forces you to write clearly. And to ditch the jargon and terms that eyeballs just gloss over.  ^278319257

---

Like many others. Better to do the heavy lifting for the reader. Because they certainly won’t. They’ll stop and leave, versus stay and scroll.  ^278319258

---

Do the work. Say something real. Practice on your kid, mom, or any outsider to tell your important and useful message.
Your readers will appreciate it. It makes good business sense.  ^278319259

---

Words that paint a picture for how the reader’s life will improve, that’s the ticket.  ^278319260

---

3. Write to the reader  ^278319261

---

Make them the hero.  ^278319262

---

Because no one cares about what you (or I) do. Readers only care what they can get from what you (or I) do.  ^278319263

---

write with a purpose to raise your signal, lessen your noise  ^278319264

---

What action do you want the reader to take?
Click the buy, call, or contact us button?
Or maybe you just want them to feel a certain way. Empathy? Bliss? Informed?  ^278319265

---

keep your mind on the target while you write.  ^278319266

---

4. Write with a purpose  ^278319267

---

write that purpose at the top of your draft piece.  ^278319268

---

5. Write to make the reader feel successful  ^278319269

---

Lead your reader down the page by breaking up your message.  ^278319270

---

Short paragraphs. Short sentences. Transition lines. Bullets. Some bolded items, too. Like this one…  ^278319271

---

Allowing your readers to skim and scan your message is nice.  ^278319272

---

What are you doing to help your readers scroll down the page  ^278319273

---

6. Write with a hyper-focus  ^278319274

---

By defining and going after a small section or piece of your post, document or whatever you’re writing. Right now. Say, in the 15 minutes before your next meeting.  ^278319275

---

Progress made. Feels good.  ^278319276

---

Define a small portion to write (I’m doing this right now for this single section)
Set a tomato timer, that you can hear going tick-tock-tick-tock
Barf it out (like we talked about above)
Make your edits
Finí
Go to your meeting  ^278319277

---

7. Use pictures to enhance the words  ^278319278

---

pictures enhance the words.  ^278319279

---

7 writing tools for social media  ^278319280

