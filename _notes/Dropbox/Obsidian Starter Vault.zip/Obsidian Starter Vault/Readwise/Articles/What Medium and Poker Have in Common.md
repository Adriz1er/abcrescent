%%
ID: 13205065
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

# About
Title: [[What Medium and Poker Have in Common]]
Author: [[Lucy Milanova]]
Category: #articles
Number of Highlights: ==2==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205065
Source URL: https://medium.com/p/844ac5ad30eb


# Highlights 
Medium is great  ^278321631

---

Expecting Medium to make me a living is like playing poker and expecting the same  ^278321632

