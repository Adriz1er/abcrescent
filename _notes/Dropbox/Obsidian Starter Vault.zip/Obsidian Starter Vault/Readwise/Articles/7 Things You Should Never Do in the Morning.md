%%
ID: 13205067
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

# About
Title: [[7 Things You Should Never Do in the Morning]]
Author: [[Sinem Günel]]
Category: #articles
Number of Highlights: ==2==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205067
Source URL: https://medium.com/p/2ccd8f7ac89d


# Highlights 
will help yo  ^278321635

---

energy on prioritizing your tasks and lack that mental power when it comes to doing all these things  ^278321636

