%%
ID: 13205055
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

# About
Title: [[Best Wishes for the New Addition to Your Routine -)]]
Author: [[Dipanshu Rawal]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205055
Source URL: https://medium.com/p/de7600641149


# Highlights 
addition to  ^278321611

