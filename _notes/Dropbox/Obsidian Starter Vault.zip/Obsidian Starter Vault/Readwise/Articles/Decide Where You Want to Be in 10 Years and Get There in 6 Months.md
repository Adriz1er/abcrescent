%%
ID: 13204943
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

# About
Title: [[Decide Where You Want to Be in 10 Years and Get There in 6 Months]]
Author: [[Vincent Carlos]]
Category: #articles
Number of Highlights: ==12==
Last Highlighted: *2021-11-25*
Readwise URL: https://readwise.io/bookreview/13204943
Source URL: https://medium.com/the-ascent/decide-where-you-want-to-be-in-10-years-and-get-there-in-6-months-ce390596d76f


# Highlights 
think about every big new idea that you’ve learned in just the last 5 years of your life.  ^278319944

---

could’ve easily started my journey 5 years earlier than I did and be a lot further ahead than I am now. Bu  ^278319945

---

. I wasn’t curious enough.  ^278319946

---

people don’t try to actively seek out new ideas or new ways of doing things. Instead, most people just spend most of their time trying to figure things out on their own.  ^278319947

---

cut the learning curve  ^278319948

---

You need to read a lot.  ^278319949

---

Reading books and articles from individuals who have done what you are looking to do will cut the learning curve by months, years, even decades for you.  ^278319950

---

And 4 months later, I was named a LinkedIn Top Voice. Something that should’ve taken me years to accomplish only took me a few months.  ^278319951

---

There’s the long conventional path. And then there’s the shorter less conventional path.  ^278319952

---

The long conventional path is the result of not being someone who actively seeks out new ideas. The long conventional path is what happens when you think you don’t have to read about other successful people in your field who are 20 years down your same path.  ^278319953

---

The penalty of trying to do everything through trial and error is that you will have to achieve everything you’re going to achieve 20 times slower.  ^278319954

---

Employ your time in improving yourself by other men’s writings, so that you shall gain easily what others have labored hard for.”  ^278319955

