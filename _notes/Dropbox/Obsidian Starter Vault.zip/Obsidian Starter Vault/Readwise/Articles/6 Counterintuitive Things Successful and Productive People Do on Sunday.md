%%
ID: 13204985
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[6 Counterintuitive Things Successful and Productive People Do on Sunday]]
Author: [[Shape]]
Category: #articles
Number of Highlights: ==8==
Last Highlighted: *2021-11-10*
Readwise URL: https://readwise.io/bookreview/13204985
Source URL: https://getpocket.com/explore/item/6-counterintuitive-things-successful-and-productive-people-do-on-sunday


# Highlights 
interviewed more than a dozen CEOs about a range of topics, including their weekend habits--from which clear themes soon emerged. I bl  ^278320639

---

equates to an energetic five-minute self pep-talk to view the week ahead as filled with promise.  ^278320640

---

On Sunday night, he specifically imagines the week ahead in chaos--because, despite the best laid plans, that's often what happens. He imagines that the week gets blown up and disorganized again.  ^278320641

---

what is the one thing that is non-negotiable, that absolutely must be accomplished no matter what happens? By imagining his week disorganized, he's able to organize around preserving the one most important thing.  ^278320642

---

plug back into your electronics for an hour to clear out the inbox and to help clear the mind so you can use Monday morning to move forward instead of sorting through back emails.  ^278320643

---

Gratitude is about developing thankfulness, not about developing an attitude  ^278320644

---

yearning to show gratitude can easily wear off during the week, so you have to force the issue on Sunday  ^278320645

---

Sunday is a day of rest. But it can additionally set up the rest of your week in a successful and productive manner.  ^278320646

