%%
ID: 13205083
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[13 Strategies to Upgrade Your 2021 Goals So You Achieve Them Months Faster]]
Author: [[Anthony Moore]]
Category: #articles
Number of Highlights: ==2==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205083
Source URL: https://medium.com/p/4658e70c0e7


# Highlights 
Successful people do what unsuccessful people are unwilling to do  ^278321660

---

“Live like no one else now, so later you can live like no one else.  ^278321661

