%%
ID: 13205071
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

# About
Title: [[How Robin Sharma’s 90901 Rule Can Help You Achieve Your Most Ambitious Goals]]
Author: [[Alexa V.S.]]
Category: #articles
Number of Highlights: ==2==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205071
Source URL: https://medium.com/p/48712d5e1d2b


# Highlights 
Months went by without any progress.  ^278321641

---

There is so much distraction available to you out there that if you are not acutely careful, it will dominate your days  ^278321642

