%%
ID: 13204982
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[Reflecting on My Failure to Build a Billion-Dollar Company]]
Author: [[Sahil Lavingia]]
Category: #articles
Number of Highlights: ==4==
Last Highlighted: *2021-11-10*
Readwise URL: https://readwise.io/bookreview/13204982
Source URL: https://marker.medium.com/reflecting-on-my-failure-to-build-a-billion-dollar-company-b0c31d7db0e7


# Highlights 
I was on top of the world. I was just 19, a solo founder, with over $8M in the bank and three employees. The world was starting to take note.  ^278320584

---

We grew the team. We stayed focused on our product. The monthly numbers started to climb. And then, at some point, they didn’t.  ^278320585

---

The online creator movement was still nascent; the slow growth wasn’t our fault. It always looked like change was right around the corner  ^278320586

---

For years, my only metric of success was building a billion-dollar company. Now, I realize that was a terrible goal.  ^278320587

