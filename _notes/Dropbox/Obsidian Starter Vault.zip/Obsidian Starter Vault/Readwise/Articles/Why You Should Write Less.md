%%
ID: 13205066
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

# About
Title: [[Why You Should Write Less]]
Author: [[Martin Vidal]]
Category: #articles
Number of Highlights: ==2==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205066
Source URL: https://medium.com/p/f882e412ca74


# Highlights 
Just as with the bodybuilders and athletes, diet and digestion are as critical to development as exercise.  ^278321633

---

You are what you eat  ^278321634

