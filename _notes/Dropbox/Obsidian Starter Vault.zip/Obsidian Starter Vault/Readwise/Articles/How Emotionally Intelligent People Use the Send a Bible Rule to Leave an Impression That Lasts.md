%%
ID: 13204922
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[How Emotionally Intelligent People Use the Send a Bible Rule to Leave an Impression That Lasts]]
Author: [[Bill Murphy Jr.]]
Category: #articles
Number of Highlights: ==4==
Last Highlighted: *2021-12-14*
Readwise URL: https://readwise.io/bookreview/13204922
Source URL: https://www.inc.com/bill-murphy-jr/how-emotionally-intelligent-people-use-send-a-bible-rule-to-become-remarkably-more-memorable.html


# Highlights 
story about friendship, emotional intelligence, and learning to say things so that other people remember them.  ^278319449

---

I realized that my friend had just taught a masterclass in how to communicate with people effectively by using emotional intelligence -- especially in tricky situations.  ^278319450

---

communicating via multiple attentions.  ^278319451

---

one of the hardest things in any important communication is knowing whether the people you're communicating with are truly hearing what you have to say.  ^278319452

