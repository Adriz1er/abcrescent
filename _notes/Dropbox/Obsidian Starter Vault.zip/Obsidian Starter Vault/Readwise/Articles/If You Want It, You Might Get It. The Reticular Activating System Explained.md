%%
ID: 13205078
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[If You Want It, You Might Get It. The Reticular Activating System Explained]]
Author: [[Tobias van Schneider]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205078
Source URL: https://medium.com/p/761b6ac14e53


# Highlights 
on you learn a new word and then start hearing it everywhere. It’s why you can tune out a crowd full of talking people, yet immediately snap to attention when someone says your name or something that at least sounds like it.  ^278321649

