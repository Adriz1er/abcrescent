# 13 Shocking Facts About How We Waste Time
#done 
![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)
[[ReadWise]]
## Metadata
- Author: [[ModernTraction.com]]
- Full Title: 13 Shocking Facts About How We Waste Time
- Category: #articles
- URL: http://hughculver.com/13-shocking-facts-about-how-we-waste-time/

## Highlights
- Apparently, when it comes to protecting your time and productivity I’ve been operating at a kindergarten level.
- He’s also managed to become a best-selling author without any social media accounts.
- The problem is when wasting time becomes normal
- “Tell me how you use your spare time, and how you spend your money, and I will tell you where 
  and what you will be in ten years from now.” Napoleon Hill
- 2.34 hours checking email (30% are neither urgent nor important.) (Carleton University)
  35 minutes deciding what to eat (New York Post)
  16 minutes deciding what to wear (women) (The Telegraph) 14 minutes for men (Marks and Spencer)
  7 minutes thinking about exercise (but doing nothing) (Kettler)
  The average person spends 7 minutes a day thinking about exercise (but doing nothing). Click To Tweet
  37 minutes on Facebook (Verto Analytics)
  27 minutes on other social media accounts (eMarketer)
  40 minutes on YouTube (really!?) (Mediakix)
  1 hour in meetings (Inc) and 50% of that time is wasted (Atlassian)
  The average office worker spends 1 hour in meetings and 50% of that time is wasted. Click To Tweet
  4 hours watching TV (Statista)
  96 minutes surfing non-work related websites (CNBC)
  171 minutes checking your smartphone (comScore)
  90 mins in daily interruptions (such as colleagues asking questions) (WashingtonPost)
  2 minutes – spent reading this list (Hey! I wanted 13 in my list)
  What I didn’t include is another scary list of guilty parties, including:
- time during commutes NOT learning from books, ebooks, audiobooks or podcasts.
  time worrying about outcomes that won’t happen or you can’t do anything about.
  time frustrated about someone’s attitudes, activities or how they brush their teeth.
  time spent thinking about working on something (like phoning a client, outsourcing an unwanted job, or preparing for a meeting) but doing nothing.
  time spent learning how to do something (like graphic design, Facebook advertising, research or fixing your lawnmower) that someone can do for half the price in half the time.
  time spent making lists over and over, but never moving forward on important work.
# 13 Shocking Facts About How We Waste Time

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[hughculver.com]]
- Full Title: 13 Shocking Facts About How We Waste Time
- Category: #articles
- URL: http://hughculver.com/13-shocking-facts-about-how-we-waste-time/

## Highlights
- Apparently, when it comes to protecting your time and productivity I’ve been operating at a kindergarten level.
- He’s also managed to become a best-selling author without any social media accounts.
- The problem is when wasting time becomes normal
- “Tell me how you use your spare time, and how you spend your money, and I will tell you where 
  and what you will be in ten years from now.” Napoleon Hill
- 2.34 hours checking email (30% are neither urgent nor important.) (Carleton University)
  35 minutes deciding what to eat (New York Post)
  16 minutes deciding what to wear (women) (The Telegraph) 14 minutes for men (Marks and Spencer)
  7 minutes thinking about exercise (but doing nothing) (Kettler)
  The average person spends 7 minutes a day thinking about exercise (but doing nothing). Click To Tweet
  37 minutes on Facebook (Verto Analytics)
  27 minutes on other social media accounts (eMarketer)
  40 minutes on YouTube (really!?) (Mediakix)
  1 hour in meetings (Inc) and 50% of that time is wasted (Atlassian)
  The average office worker spends 1 hour in meetings and 50% of that time is wasted. Click To Tweet
  4 hours watching TV (Statista)
  96 minutes surfing non-work related websites (CNBC)
  171 minutes checking your smartphone (comScore)
  90 mins in daily interruptions (such as colleagues asking questions) (WashingtonPost)
  2 minutes – spent reading this list (Hey! I wanted 13 in my list)
  What I didn’t include is another scary list of guilty parties, including:
- time during commutes NOT learning from books, ebooks, audiobooks or podcasts.
  time worrying about outcomes that won’t happen or you can’t do anything about.
  time frustrated about someone’s attitudes, activities or how they brush their teeth.
  time spent thinking about working on something (like phoning a client, outsourcing an unwanted job, or preparing for a meeting) but doing nothing.
  time spent learning how to do something (like graphic design, Facebook advertising, research or fixing your lawnmower) that someone can do for half the price in half the time.
  time spent making lists over and over, but never moving forward on important work.
