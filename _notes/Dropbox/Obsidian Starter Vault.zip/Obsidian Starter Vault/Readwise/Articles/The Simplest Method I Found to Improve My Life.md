%%
ID: 13205058
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

# About
Title: [[The Simplest Method I Found to Improve My Life]]
Author: [[TheTrix]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205058
Source URL: https://medium.com/p/10fc2b1937b4


# Highlights 
Do the opposite of what my inner voice suggests to do!  ^278321616

