%%
ID: 13205079
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

# About
Title: [[How to Close the Gap Between the Life You Live and the Life You Want]]
Author: [[Sinem Günel]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205079
Source URL: https://medium.com/p/df6a2530925


# Highlights 
If your goal is to make $100,000 of revenue in a year, there’s no urgency to take massive action in January because you might believe there’s plenty of time to do it later during the year.  ^278321650

