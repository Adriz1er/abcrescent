%%
ID: 13204935
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

# About
Title: [[The #1 Rule of “NO”]]
Author: [[jamesaltucher.com]]
Category: #articles
Number of Highlights: ==7==
Last Highlighted: *2021-11-28*
Readwise URL: https://readwise.io/bookreview/13204935
Source URL: https://jamesaltucher.com/blog/1-rule-no/


# Highlights 
No” feels like I’m saying, “I will never succeed”. I’m scared to say it.  ^278319842

---

maybe hurting someone who will then trash me. Am I turning down opportunity?  ^278319843

---

Will the gods of good fortune no longer look at me with hope and optimism?  ^278319844

---

The other day, a well known entrepreneur wrote me and said he had a great opportunity. “Maybe billions!”
But I don’t want to talk to him. I simply can’t pick up the phone and call him.  ^278319845

---

They want to know right now: “Yes!” or “No!” “Please say YES!”
But I want to say “No  ^278319846

---

Here’s the RULES OF NO:
Two out of these three have to trigger for me to say YES:
– KNOWLEDGE: Will I learn something
– FUN: Is it fun
– MONEY: Is it financially worthwhile.  ^278319847

---

I won’t learn anything new from speaking. It’s not fun to fly for a day, speak for 30 minutes, fly home for a day. And I have no financial benefit.  ^278319848

