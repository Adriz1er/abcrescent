%%
ID: 13204939
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[Why I Experiment Every Day]]
Author: [[jamesaltucher.com]]
Category: #articles
Number of Highlights: ==13==
Last Highlighted: *2021-11-28*
Readwise URL: https://readwise.io/bookreview/13204939
Source URL: https://jamesaltucher.com/blog/why-i-experiment-every-day/


# Highlights 
It’s ok for experiments to go bad. It’s ok to not be perfect I tell myself. I have to give myself permission to accept my imperfections. Else life is too stressful.  ^278319870

---

And I worry about the things that everyone worries about – are my decisions correct enough to survive me until my dealth  ^278319871

---

It’s ok to experiment and move on. How many times can you experiment in this life before you die?  ^278319872

---

It is ONLY through experimenting that we start to carve out the parts of the world we don’t know about. We find out what we love and enjoy. There is no other way.  ^278319873

---

Should I do X? Or Y? Find 50 ways to experiment answering this question.  ^278319874

---

Should I call someone I haven’t spoken to in years? Or not call them?  ^278319875

---

Each experiment allows me to play with my comfort zone. And to learn more about the world. And to learn more about myself. And to learn more about whatever it is I am specifically experimenting about.  ^278319876

---

Can I interview one person and unlock a secret that will help the rest of humanity.  ^278319877

---

Can I meet someone and build a connection between him (or her) and me. One that lasts beyond the handshake.  ^278319878

---

Learning how to experiment with your life is a muscle. You have to practice it every day. But, for me, it makes my life better. Even the bad experiments  ^278319879

---

But all of the reviewers will die one day. And so will I. And so will you. We’re all in a race to the finish line.  ^278319880

---

Life is measured not by our good deeds, or by who loved us, or by what charities we’ve done, but by the number of experiments we did.  ^278319881

---

some experiments fizzle out to nothing. And some experiments blow up. Blow up in our faces, Blow up and from a satellite in space looking down, created flash of light that can be seen by the entire universe.  ^278319882

