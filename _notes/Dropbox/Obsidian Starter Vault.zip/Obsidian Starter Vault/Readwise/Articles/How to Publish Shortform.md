%%
ID: 13222791
Updated: 2022-01-29
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

# About
Title: [[How to Publish Shortform]]
Author: [[Michelle Legro]]
Category: #articles
Number of Highlights: ==7==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13222791
Source URL: https://medium.com/creators-hub/how-to-publish-shortform-c059b5fda2d5


# Highlights 
Vary the writing on your profile page. Not all of our articles are created equal, right?  ^278699034

---

What’s long, what’s medium length, and what’s short?  ^278699035

---

Introduce the reader into your profile stream.  ^278699036

---

Shout out an article, or another writer.  ^278699037

---

The tools  ^278699038

---

If you’re writing about a person, tag them.  ^278699039

---

When it comes to publishing shortform, variation—and consistency within that variation—is the key. Once you develop some formats that work for you, stick with them!  ^278699040

