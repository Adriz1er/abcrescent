# How I Write 1–2 Articles Everyday for Medium — My Strategy

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Har Narayan]]
- Full Title: How I Write 1–2 Articles Everyday for Medium — My Strategy
- Category: #articles
- URL: https://medium.com/@har.narayan/how-i-write-1-2-articles-everyday-for-medium-my-strategy-b26416380c64

## Highlights
- Once you know how to play the game effectively.
- Yes, writing is a game. Either you lose or you win, but as long as you play the game you never lose because you’re in the game
- Strategy 1: Come up with An Idea
- Ideas could be anything like your past experience your knowledge or your thoughts, opinions, anything. Maybe it's your medium post that you’re reading of other writers and you suddenly come up with an idea.
- Strategy 2: Making A Daily Draft
- the next step you have to do is just make a draft of that idea
- The first thing you have to do is write the headline of that idea and if you have much knowledge about that topic at that time write it down all the elements immediately.
- if you don’t write that idea at that particular time, most likely you’re going to forget that idea. Because you can’t keep all the thoughts that are going on in your brain.
- If you make daily 4 to 5 drafts as I do then you’re never going to out of the content idea
- The Power Of Exact Time Setup
- After making the drafts, the next step is to set an exact time for your writing period.
- Set an exact time for your writing. don't just write randomly
- When you set an exact time for your writing, it will force you to write daily, and help you to make a habit of daily writing, nobody else would matter except the writing at that time
- If you set the time in the morning from 8 am to 11 am don't do anything that time use that time for only writing. if you set the time in the evening from 5 pm to 7 pm just write on that time — nothing else.
- Forget everything else and just — write, write and write.That's what we called — Self Discipline
- Strategy 4: Personal Responsibility
- I write in the afternoon from 1 pm to 3 pm and in the night from 8 pm to 10 pm at that time nothing else matters to me. I just write and write on that timeframe. That’s how I built my writing habit. Trust me this is so powerful strategy to write daily.
- it’s your personal responsibility to write, it's your work to get the things done ASAP.
- Despite if you feel like that, all you have to do is — Remind your goals, your ambitions, what you wanted to be? And why you had started to write? When you will ask these questions, simultaneously you will get the answers to that questions. Which will give you motivation, and energy to write.
