%%
ID: 13205080
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

# About
Title: [[You Won’t Succeed on Medium (And Life) if You Keep Doing These 3 Things]]
Author: [[Sinem Günel]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205080
Source URL: https://medium.com/p/c577914c6f6b


# Highlights 
The moment you think you know it all is the moment you lose the game — on Medium, in business, but also in life.  ^278321651

