%%
ID: 13204896
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

# About
Title: [[I’m Using These Magic Words to Write 100,000 Words This Week]]
Author: [[Edina Abena Jackson]]
Category: #articles
Number of Highlights: ==6==
Last Highlighted: *2022-01-19*
Readwise URL: https://readwise.io/bookreview/13204896
Source URL: https://intriguework.medium.com/im-using-these-magic-words-to-write-100-000-words-this-week-b3e9b4441159


# Highlights 
These are the five magic words that force me out of bed every morning. These are the five magic words that lure my fingers to the keyboard to get the writing done on days when I am just not in the mood. I tell myself that this is my life and that’s just what I do. These words help to build strong, healthy habits.  ^278319020

---

Scared of failure and scared of pushing the publish button  ^278319021

---

Stepping out of my comfort zone is the name of the game.  ^278319022

---

Last year, I smashed most of my writing goals however, most days, I sat writing with fear and anxiety.  ^278319023

---

I just want to tick things off my list of things to do and move on to the next task. I am extremely passionate about content creation and failure is not an option for me at this point.  ^278319024

---

“That’s just what I do.”  ^278319025

