%%
ID: 13204955
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

# About
Title: [[I Work in Porn. I Know Why So Many Men Are Single]]
Author: [[Ossiana Tepfenhart]]
Category: #articles
Number of Highlights: ==27==
Last Highlighted: *2021-11-25*
Readwise URL: https://readwise.io/bookreview/13204955
Source URL: https://medium.com/@ossiana.tepfenhart/i-work-in-porn-i-know-why-so-many-men-are-single-626810d98b1f


# Highlights 
you don’t have to be 6'1 with a sick physique to get laid.  ^278320107

---

Everyone is someone’s fantasy, and your looks only are one small factor among many that make relationships possible.  ^278320108

---

also know how many men have crazy struggles trying to find (and keep) a partner. It feels like an uphill battle, and I see it with my friends all the time.  ^278320109

---

Ever wonder what’s going on here? Why are so many men single these days? I got a little insight for you.  ^278320110

---

Social skills are not as common as they once were  ^278320111

---

When I was younger, you needed to have social skills to survive. If you couldn’t figure out how to act normal, you would have no friends, no hobbies, and no dating prospects  ^278320112

---

The internet changed that  ^278320113

---

that lack of social skills means you can’t present your best self to a potential partner  ^278320114

---

They’re being fed a steady diet of unhealthy (or even downright toxic) dating advice  ^278320115

---

It wrecks your image of yourself. No one short of male models will live up to the standards that men think women want.  ^278320116

---

You can’t really love or respect women if you’re going on forums and talking about how awful we are  ^278320117

---

advice you get is borderline abusive  ^278320118

---

Women are growing aware of these techniques, and are learning to dump men who use this stuff. Nobody wants to knowingly link up with an abuser or someone who clearly wants to use us.  ^278320119

---

Try to befriend women. Actually listen to them and learn to see them as people. In many cases, this can make your dating life blossom faster than anything else.  ^278320120

---

What we consume in media is what we tend to expect around us  ^278320121

---

Unfortunately, media tends to make men think that they all will get a modelesque woman with minimal effort.  ^278320122

---

We live in a world where healthy relationships are not really noticed that often. Or even highlighted. Sure as hell, we don’t mention how much work it is to deal with even the nicest relationship  ^278320123

---

Many men feel like relationships are too much effort and cost too much money for them  ^278320124

---

I am all for men who want to take a break from dating. If you feel like dating is hurting you rather than improving your life, you have every right to say “Enough is enough.”  ^278320125

---

Sometimes, not caring about dating is actually what gives you the energy you need to attract others. Walking away is healthier than continuing your dating journey while you get increasingly resentful  ^278320126

---

men tend to opt for women who they feel make them look good to other men. If  ^278320127

---

status does not equate to compatibility. If you’re lying to yourself about what you’re into, you’re going to have a bad relationship.  ^278320128

---

True story. I have a guyfriend who is straight as an arrow, but never met someone that really made him go “WOW.” He’s holding out for his WOW. We can all respect that.  ^278320129

---

Healthy women desire healthy men.  ^278320130

---

It’s okay to work on yourself before you get into a relationship. Everyone has their own issues, and it’s best to have something to offer a potential partner aside from sex and companionship before you start dating.  ^278320131

---

Like attracts like. It’s a natural law, or something.  ^278320132

---

What I’m saying is that bad luck happens to all of us. Sometimes, timing isn’t right. Sometimes, we come off weird, or ask out the wrong person at the wrong time. It happens to the best of us. The most we can all do is enjoy the pizza along the way.  ^278320133

