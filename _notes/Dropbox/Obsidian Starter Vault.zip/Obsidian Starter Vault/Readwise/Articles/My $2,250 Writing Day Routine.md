%%
ID: 13204952
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

# About
Title: [[My $2,250 Writing Day Routine]]
Author: [[Michael Leonard]]
Category: #articles
Number of Highlights: ==8==
Last Highlighted: *2021-11-26*
Readwise URL: https://readwise.io/bookreview/13204952
Source URL: https://bettermarketing.pub/my-2-250-writing-day-routine-2bf7ceeae0a7


# Highlights 
build an online business and pursue professional golf.  ^278320053

---

In the writing side of my business, I pump out quite a bit of content each month. I  ^278320054

---

If I feel stressed or flustered, no one is going to read my best stuff  ^278320055

---

Use the Pomodoro Technique: I  ^278320056

---

Write about stuff you love: I  ^278320057

---

Do what works best for you:  ^278320058

---

Write and edit separately: As  ^278320059

---

would go days barely having any real conversations with human beings. Being an extrovert, this really killed my energy at times. Know your personality and what type of environment you need to thrive.  ^278320060

