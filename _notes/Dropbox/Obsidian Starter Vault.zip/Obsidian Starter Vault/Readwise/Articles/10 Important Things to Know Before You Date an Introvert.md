%%
ID: 13205063
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[10 Important Things to Know Before You Date an Introvert]]
Author: [[Maryam]]
Category: #articles
Number of Highlights: ==2==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205063
Source URL: https://medium.com/p/5654302ecf2b


# Highlights 
I am an introvert and I love myself.  ^278321628

---

They don’t like to put up their photos on social media. They want things to be private  ^278321629

