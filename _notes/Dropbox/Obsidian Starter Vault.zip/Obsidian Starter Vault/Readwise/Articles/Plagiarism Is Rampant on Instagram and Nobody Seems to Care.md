%%
ID: 13204918
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[Plagiarism Is Rampant on Instagram and Nobody Seems to Care]]
Author: [[Zulie Rane]]
Category: #articles
Number of Highlights: ==11==
Last Highlighted: *2021-12-14*
Readwise URL: https://readwise.io/bookreview/13204918
Source URL: https://onezero.medium.com/plagiarism-is-rampant-on-instagram-and-nobody-seems-to-care-6b5376b35afd


# Highlights 
One of the cat accounts I follow, @pawsomecouture, posted a screenshot of a funny cat tweet on their account. In the caption, they’d credited the Twitter account that had originally posted it. But they hadn’t linked to her account, or tagged her Instagram account.  ^278319379

---

In what other profession would it be acceptable to take something someone else had made and post it to a profitable brand account page without some kind of recompense?  ^278319380

---

The internet is a tough and wonderful place to create.  ^278319381

---

if Pawsome Couture copies a tweet and uses that to build their audience on Instagram where they sell cat toys and pay no proportion of their profit to the content creators, it’s theft, plain and simple.  ^278319382

---

going viral was all any creator could want or expect. Speaking for myself, I loved posting videos and photos of my cat that would go “viral,” racking up 1,000s of likes. It didn’t pay a single cat food bill, but the sensation of being popular online was addictive.  ^278319383

---

creators themselves seemed to prefer virality above payment.  ^278319384

---

Virality is its own reward to many people, worth harassment, the knowledge that you’re wrong, and in the case of the creator fund, actively missing out on cash.  ^278319385

---

Brands Won’t Stop at Stealing Content  ^278319386

---

Brands steal free content, which is bad enough. But it opens the door to stealing the very livelihood under the feet of creators.  ^278319387

---

start valuing the work of others. If you like something, be prepared to pay for it  ^278319388

---

if you’re a creator? Start valuing your own work. Brands won’t. Platforms won’t. And your audience won’t until you start doing it for yourself.  ^278319389

