%%
ID: 13205075
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[12 Things I Learned About Money Far Too Late in Life]]
Author: [[Tim Denning]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205075
Source URL: https://medium.com/p/c85486329ffa


# Highlights 
Big bets ruin you financially.
Small diversified investments allow for the inevitable downside  ^278321646

