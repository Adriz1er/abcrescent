%%
ID: 13205057
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[Financial Freedom Starts Out Being Absolutely Brutal]]
Author: [[Tim Denning]]
Category: #articles
Number of Highlights: ==3==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205057
Source URL: https://medium.com/p/be8d7b3a33f


# Highlights 
It takes effort to create enough value that you don’t have to stress about money anymore  ^278321613

---

I cared more about what I was doing and that led me to communicate differently. Instead of ignoring people I did my best to be helpful.  ^278321614

---

you’ve done something people think is extraordinary. What those people didn’t see was all the effort you put in behind the scenes.  ^278321615

