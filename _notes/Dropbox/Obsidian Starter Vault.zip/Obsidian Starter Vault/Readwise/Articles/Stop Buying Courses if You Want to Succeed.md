%%
ID: 13205062
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[Stop Buying Courses if You Want to Succeed]]
Author: [[Avery Strange]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205062
Source URL: https://medium.com/p/11f4b29d4d5a


# Highlights 
Courses are procrastination with a sexier name.  ^278321622

