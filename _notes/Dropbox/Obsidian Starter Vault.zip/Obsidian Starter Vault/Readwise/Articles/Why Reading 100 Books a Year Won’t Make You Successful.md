%%
ID: 13205085
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[Why Reading 100 Books a Year Won’t Make You Successful]]
Author: [[Aytekin Tank]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205085
Source URL: https://medium.com/p/1863dad5944d


# Highlights 
An entire page can’t be read at once. Zig-zagging down one page doesn’t work. The human eye just isn’t up to it.  ^278321663

