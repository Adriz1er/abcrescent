# We Screwed Up the Purpose of Life. It’s to Create.

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Tim Denning]]
- Full Title: We Screwed Up the Purpose of Life. It’s to Create.
- Category: #articles
- URL: https://medium.com/curious/we-screwed-up-the-purpose-of-life-its-to-create-c26e3bcc9f48

## Highlights
- Cliches ruin our lives.
- One of the most common is, the purpose of life is to be happy.
- Nope
- There’s a different way to think about purpose.It’ll unlock a new dimension in your life.
- Happiness can screw up your life
- went out every night and partied. My occupation was DJ. This gave me a legitimate license to thrill. My parents complained.
- I drank more than a fish.
- I saw everybody and everything as a competitor to my happiness. If anyone screwed with my happiness, I screwed with their life.
- I realized that chasing happiness can become narcissism, selfishness, Dunning-Kruger, dictator-like behavior, and drunkenness.
- The #1 blocker of creation
- It’s because too few do it and it ruins our purpose in life
- We’re not stupid. Deep down we know we need to create. However, dopamine-driven behavior messed up our purpose.
- There is a reason the word ‘creator’ has become popular
- It’s easier to trade stocks daily than create a startupIt’s easier to read Twitter posts but never create your ownIt’s easier to read millions of books but never write oneIt’s easier to watch a Netflix drama than become an actor
- The internet has amplified consumerism. Distractions are now amplified. As a result, creation is a low priority.
- We want freedom for a bizarre reason
- Freedom ads are everywhere.
- Many people think making money online to access more freedom is a con job. They think creators like me want to be lazy and do nothing.
- It’s the opposite.We want to access freedom so we have more time to create.That’s why I invested my money heavily over the last few years and quit my job. I didn’t want a Lambo or to buy some fake form of happiness.
- True creation is done freely.Those who have realized the purpose of life is to create are starting to realize that creation done in handcuffs isn’t true creation.
- Change is inevitable as we discover this new purpose for ourselves and exits the Matrix of too much consumption.
- You could live foreverYour creations don’t die with you. They get left behind. People remember them. People continue to enjoy them. People continue to learn from them.It’s weird to think about — but what if you could live forever through your creations?You can.Create more to leave behind evidence of who you are, so you live forever.
