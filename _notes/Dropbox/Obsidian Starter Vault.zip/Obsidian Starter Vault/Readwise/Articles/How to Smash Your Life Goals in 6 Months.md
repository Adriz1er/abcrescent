%%
ID: 13204947
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

# About
Title: [[How to Smash Your Life Goals in 6 Months]]
Author: [[Scott Stockdale]]
Category: #articles
Number of Highlights: ==6==
Last Highlighted: *2021-11-26*
Readwise URL: https://readwise.io/bookreview/13204947
Source URL: https://medium.com/swlh/how-to-smash-your-life-goals-in-6-months-72966bac5c66


# Highlights 
None of this would have happened without a 6-month plan  ^278319999

---

A 6-month plan is a living, breathing document. You’ll be reviewing it every day (ideally), and it’ll help you work towards your goals.  ^278320000

---

Before you decide on your goals, consider Pat Flynn’s question: Can I commit to this project for three years?  ^278320001

---

. If you want to learn a new skill, Google can teach you how  ^278320002

---

What’ll you discover is God, the Universe, coincidence — whatever its name — seems to conspire in your favour once you’ve got clarity on your goals.  ^278320003

---

This is arguably the most important section.Every day, I spend ten minutes journalling in my Google doc. I type whatever pops into my head. I liken it to downloading my subconscious thoughts.  ^278320004

