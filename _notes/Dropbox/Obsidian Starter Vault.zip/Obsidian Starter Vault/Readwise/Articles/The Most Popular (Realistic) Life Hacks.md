%%
ID: 13205086
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[The Most Popular (Realistic) Life Hacks]]
Author: [[Tim Denning]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205086
Source URL: https://medium.com/p/f1c4faa83465


# Highlights 
Eat fruits and veggies  ^278321664

