%%
ID: 13204900
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

# About
Title: [[Reader Expectation Approach]]
Author: [[georgegopen.com]]
Category: #articles
Number of Highlights: ==4==
Last Highlighted: *2022-01-25*
Readwise URL: https://readwise.io/bookreview/13204900
Source URL: https://georgegopen.com/reader-expectation-approach


# Highlights 
no one cares how hard the writer tried nor how much improvement has been demonstrated since last time.  ^278319099

---

Did the reader get delivery of what the writer was intending to send  ^278319100

---

If the answer is “yes,” the writing was good enough; if “no,” it wasn’t.  ^278319101

---

What is going on here?
Whose story is this?
How does this sentence connect backwards and forwards to its neighbors?
What word or words in this sentence should be read with special emphasis because they are the stars of this show?  ^278319102

