%%
ID: 13205088
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

# About
Title: [[5 Must-Have Skills Every Content Creator Needs to Succeed in the 21st Century]]
Author: [[Omar Itani]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205088
Source URL: https://medium.com/p/630629e08250


# Highlights 
[In our new knowledge economy] if you don’t produce, you won’t thrive — no matter how skilled or talented you are.”  ^278321666

