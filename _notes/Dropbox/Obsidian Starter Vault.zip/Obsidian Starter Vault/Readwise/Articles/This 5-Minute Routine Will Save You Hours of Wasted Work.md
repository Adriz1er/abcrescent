%%
ID: 13204912
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

# About
Title: [[This 5-Minute Routine Will Save You Hours of Wasted Work]]
Author: [[Dom Price]]
Category: #articles
Number of Highlights: ==6==
Last Highlighted: *2021-12-20*
Readwise URL: https://readwise.io/bookreview/13204912
Source URL: https://www.inc.com/dom-price/a-simple-trick-for-insanely-productive-weeks.html


# Highlights 
It's called the "daily stand-up," and high-performing software teams have been doing them for over a decade.  ^278319281

---

Workplace productivity data show why it matters.  ^278319282

---

coordination and communication within and across teams are critical to productivity.  ^278319283

---

more email equals more stress--and stressed-out employees take almost twice as many sick days, and are less productive when they're in the office.  ^278319284

---

Stand-ups are a great alternative to email because they're not just quick, they increase engagement between workers (flip through the SlideShare below, and you'll see how). Plus, they're fast-paced and high-energy, both of which give the ol' daily routine a nice shot in the arm.  ^278319285

---

Being transparent about what you're working on is the easiest way to ensure things keep moving smoothly for everyone. Try stand-ups with your team this week.  ^278319286

