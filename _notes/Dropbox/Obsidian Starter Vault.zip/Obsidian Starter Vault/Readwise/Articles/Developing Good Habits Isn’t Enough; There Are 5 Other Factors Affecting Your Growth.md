%%
ID: 13205074
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[Developing Good Habits Isn’t Enough; There Are 5 Other Factors Affecting Your Growth]]
Author: [[Dipanshu Rawal]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205074
Source URL: https://medium.com/p/cab1f6efd67f


# Highlights 
Your ‘why’ and your reason — your life purpose and everything that is important to you  ^278321645

