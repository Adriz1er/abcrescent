# No Meetings, No Deadlines, No Full-Time Employees

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[sahillavingia.com]]
- Full Title: No Meetings, No Deadlines, No Full-Time Employees
- Category: #articles
- URL: https://sahillavingia.com/work?utm_campaign=Sunday%20Synthesis&utm_medium=email&utm_source=Revue%20newsletter

## Highlights
- The future of work is not working
- This is what working in the creator economy should feel like
- Creators make money so they can make stuff, instead of the other way around. Why not adopt this framing at Gumroad, too?
- The internet has enabled new ways of working, but we’re just starting to see them unfold. There are a lot of different ways to make work work. Ours is just one
