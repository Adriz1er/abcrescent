# What Is Better More Effective? Day Trading? Swing Trading? Long Term? What Is the Strategy? Tips?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[9 months ago]]
- Full Title: What Is Better More Effective? Day Trading? Swing Trading? Long Term? What Is the Strategy? Tips?
- Category: #articles
- URL: https://www.reddit.com/r/smallstreetbets/comments/of7xyf/what_is_better_more_effective_day_trading_swing/

## Highlights
- when I spend hours writing a post and pour insight from a real trader that is on the battlefield everyday since 1995 it does mean much more then an author or even most money managers.
- . I would watch everyday in the journal and find the tickers, AOL didn’t get big until 1996. It was his guidance that caused me to hold them long. Eventually after close to a year the account was almost doubled at near $4,000.
- was forced to be a day trader, but I started to get a great skill set.
- Some bloody days, it is better to sit on the sidelines and do nothing. On a typical day I may do 2-4 rounds (BUY/SELL) On a bad day I do 0 of course
- I do not set stop losses. My stocks have fundamentals, if you trade garbage you get garbage and you may lose. I keep NIO, LMND, SNOW on lists so I can laugh.
- Options I learned it’s a gamble you win or go home. Though I was very successful earlier, but I lost 50k on the short and 25K on TSLA puts. We must learn from our mistakes.
- Unfortunately, I do not take losses, and my day trades turn into swing trades. Generally they never last more then 5 to 10 business days. My longest recently was 7-8 on Allstate which I sold at 106…. Now it is 112 on a defensive market.
- As a kid, I saw market makers that would focus on 2-3 all day the same ones for a month.
- Yes there are Apples, Netflix, Amazon, Invisalign (All which I did own), but remember there are close to 10,000 stocks that trade so what is the probability you own the next best thing since sliced bread?
- Trading a lot is about probability, risk on the upside, the downside. Market sentiment, as we see interest rates etc. You must monitor or I suggest the index funds.
- If you plan to be a great trader it takes a ton of patience, reading, experience and seeing the market. Do not believe you can quit your job and be a day trader for life unless you are willing to do that? Did you read my daily routine?
# What Is Better More Effective? Day Trading? Swing Trading? Long Term? What Is the Strategy? Tips?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[reddit.com]]
- Full Title: What Is Better More Effective? Day Trading? Swing Trading? Long Term? What Is the Strategy? Tips?
- Category: #articles
- URL: https://www.reddit.com/r/smallstreetbets/comments/of7xyf/what_is_better_more_effective_day_trading_swing/

## Highlights
- when I spend hours writing a post and pour insight from a real trader that is on the battlefield everyday since 1995 it does mean much more then an author or even most money managers.
- . I would watch everyday in the journal and find the tickers, AOL didn’t get big until 1996. It was his guidance that caused me to hold them long. Eventually after close to a year the account was almost doubled at near $4,000.
- was forced to be a day trader, but I started to get a great skill set.
- Some bloody days, it is better to sit on the sidelines and do nothing. On a typical day I may do 2-4 rounds (BUY/SELL) On a bad day I do 0 of course
- I do not set stop losses. My stocks have fundamentals, if you trade garbage you get garbage and you may lose. I keep NIO, LMND, SNOW on lists so I can laugh.
- Options I learned it’s a gamble you win or go home. Though I was very successful earlier, but I lost 50k on the short and 25K on TSLA puts. We must learn from our mistakes.
- Unfortunately, I do not take losses, and my day trades turn into swing trades. Generally they never last more then 5 to 10 business days. My longest recently was 7-8 on Allstate which I sold at 106…. Now it is 112 on a defensive market.
- As a kid, I saw market makers that would focus on 2-3 all day the same ones for a month.
- Yes there are Apples, Netflix, Amazon, Invisalign (All which I did own), but remember there are close to 10,000 stocks that trade so what is the probability you own the next best thing since sliced bread?
- Trading a lot is about probability, risk on the upside, the downside. Market sentiment, as we see interest rates etc. You must monitor or I suggest the index funds.
- If you plan to be a great trader it takes a ton of patience, reading, experience and seeing the market. Do not believe you can quit your job and be a day trader for life unless you are willing to do that? Did you read my daily routine?
