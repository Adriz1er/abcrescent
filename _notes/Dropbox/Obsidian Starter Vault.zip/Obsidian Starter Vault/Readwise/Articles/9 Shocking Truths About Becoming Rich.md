%%
ID: 13205068
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[9 Shocking Truths About Becoming Rich]]
Author: [[Adam Del Duca]]
Category: #articles
Number of Highlights: ==2==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205068
Source URL: https://medium.com/p/fad27bdc86db


# Highlights 
start their own businesses where your income is only limited by you  ^278321637

---

college isn’t there to help you get a job  ^278321638

