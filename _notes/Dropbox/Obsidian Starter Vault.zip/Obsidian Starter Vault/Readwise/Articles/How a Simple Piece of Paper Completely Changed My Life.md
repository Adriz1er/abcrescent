%%
ID: 13205093
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[How a Simple Piece of Paper Completely Changed My Life]]
Author: [[Anthony J. Yeung]]
Category: #articles
Number of Highlights: ==4==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205093
Source URL: https://medium.com/p/11733d25c1ac


# Highlights 
“Remember you will die.”  ^278321672

---

It’s to remain ignorant of time speeding by until, one day, you look back on your life and realize you’ve wasted it or missed countless chances because you never considered you only had a limited time on this Earth.  ^278321673

---

Seize the day, put no trust in the morrow!  ^278321674

---

For maximum results, put your chart where you can see it regularly.  ^278321675

