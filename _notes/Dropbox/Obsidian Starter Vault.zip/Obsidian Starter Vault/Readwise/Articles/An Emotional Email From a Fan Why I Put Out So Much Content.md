# An Emotional Email From a Fan: Why I Put Out So Much Content

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Gary Vaynerchuk]]
- Full Title: An Emotional Email From a Fan: Why I Put Out So Much Content
- Category: #articles
- URL: https://medium.com/@garyvee/an-emotional-email-from-a-fan-why-i-put-out-so-much-content-4b9c571a95af

## Highlights
- One of the reasons I put out so much content is so that selfishly, I can get emails from people in my audience telling me how I’ve helped them.
- Gary,I just want to express my absolute thanks. I listened to your content every day as I got ready to go to my job that I absolutely hated. It was the first job I took out of college, so I figured that was what the real world was like. You just have to suck it up and keep your head down to get money and get the things that you want. It was your advice that told me to pounce on the things that I want and not just wait for them to come to me.
- After a year of misery, I negotiated my wages so that I work a quarter of the time but make double the wages (making half the money, but saving 75% of the time). I spent the remainder of my time teaching myself to code. I know what you’ve said about this line of work and its future, but it really is my dream job.
- After many months, I still hated the job so much. It happened out of luck that at the same time cryptocurrency did well for me. I took your advice to not listen to what my family says about my decisions and I went to travel the world for what started off as a few months of curiosity in Thailand and became a year of amazement around the world.
- During that year, I learned to code more and connected with more coders who were traveling the world. I became more positive and happier too. When I came back, my friends said they noticed the positive difference in my personality.
- After a year, I finally became sick of traveling and returned home with the goals of getting a high paying job and recovering from my journey. I finally got the job offer two days ago to make more money than I had ever made in my life, doing something that would allow my skills to grow further.
- Because I took my own path, said “fuck it”, and went with the idea that I am young enough to bounce back from mistakes, I quit the job that I hated, saw every place in the world that I’ve ever wanted to see, made a ton of money to support myself as well as spoil my friends and family, and have ultimately made my Jewish grandmother very proud of me (which is the end goal, really).
- I now feel like I got my shit together for the first time in my life and I am happier and feel more alive than ever before in my life. I attribute it to your advice and guidance from the web.Thank you so much.So much love,I got emotional after reading this email.Hope it inspires you to get out there and find your own happiness :)
