%%
ID: 13204941
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

# About
Title: [[How to Get People to Like You in 5 Seconds or Less]]
Author: [[James Altucher]]
Category: #articles
Number of Highlights: ==23==
Last Highlighted: *2021-11-28*
Readwise URL: https://readwise.io/bookreview/13204941
Source URL: https://medium.com/the-mission/how-to-get-people-to-like-you-in-5-seconds-or-less-67e64cb91155


# Highlights 
For about 2.5 years I had a job that I created for myself. I had to interview people at three in the morning on a Wednesday night and find out what they were up to.  ^278319914

---

I was surprised how vibrant and exciting three in the morning was.  ^278319915

---

was too shy. I couldn’t do it. I could only watch. So I made it my job  ^278319916

---

NOBODY wanted to talk to a random stranger like me at three in the morning  ^278319917

---

Get specific. Nobody wants  ^278319918

---

Everyone wants to vomit their facts if you ask the right question.  ^278319919

---

Smiling is the best way to let them know you like them. And be genuine about it. Fake smiles are creepy.  ^278319920

---

Every time someone says anything, it’s the clothing that covers a gold secret. Dig until you find that secret because that’s the gold.  ^278319921

---

Your brain doesn’t want to talk to strangers. It wants comfort. It wants you to be safe.  ^278319922

---

We have the same genes now that we had 40,000 years ago. Talking to someone outside your tribe might have gotten you killed.  ^278319923

---

Hence, your brain will scream and shout and freeze you and cause you actual physical pain if you want to talk to someone new.  ^278319924

---

I’ll focus on the curiosity instead of the pain that SPIKES as I start to approach them.  ^278319925

---

I shouldn’t do this. There’s crap and pee on the sidewalk when I lie down. But if you stand straight and dress nice and smile, people will at least stop.They will wonder if you are an opportunity for them. Be one.  ^278319926

---

From the moment our feet finally leave the inside of our mother’s womb, until the day we die, life is a battle.  ^278319927

---

Respect everyone’s battles. Respect that everyone has it hard, or harder, than you do.  ^278319928

---

Don’t fake sympathy or sincerity. People can smell that.  ^278319929

---

I’m sorry but if I get insanely curious about something you say, is it ok if I interrupt?”  ^278319930

---

People write me and say, “Let your guest finish!”  ^278319931

---

No! I have to interrupt. I’m stupid and if I don’t understand NOW, I will never ever get the chance to understand.  ^278319932

---

Not because it’s so easy, but it’s so easy to say and so hard to do.  ^278319933

---

How do I be myself? I don’t know. I am not so self-aware.I assume I’m always the dumbest person in the room. Somehow that makes it easier to be myself.We’re all on this journey together. And it’s such a pleasure to find someone, for even just a minute, to hold hands with and kiss.  ^278319934

---

If I never climbed a ladder before but now I watch someone climb a ladder, I can now climb a ladder.  ^278319935

---

If I watch standup comedy I won’t be a standup comedian but I can talk better, I can be a little funnier, I can do more things with my voice and face, I’m more at ease.  ^278319936

