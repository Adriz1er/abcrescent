%%
ID: 13205089
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

# About
Title: [[James Clear’s #1 Strategy  for Earning 1,000,000 Email Subscribers Could Save the Internet]]
Author: [[Michael Thompson]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205089
Source URL: https://medium.com/p/708d5add15d2


# Highlights 
Every action you take is a vote for the type of person you wish to become.”  ^278321667

