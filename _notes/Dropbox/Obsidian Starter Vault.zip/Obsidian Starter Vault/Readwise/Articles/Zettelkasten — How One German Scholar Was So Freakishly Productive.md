%%
ID: 13205094
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

# About
Title: [[Zettelkasten — How One German Scholar Was So Freakishly Productive]]
Author: [[David B. Clear]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13205094
Source URL: https://medium.com/p/997e4e0ca125


# Highlights 
note is just an element that derives its quality from the network of links in the system. A note that is not connected to the network will be lost, will be forgotten  ^278321676

