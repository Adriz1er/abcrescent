%%
ID: 13204965
Updated: 2022-01-28
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

# About
Title: [[How I Read 20 Articles a Day Using Instapaper, Readwise, Amazon Kindle, and Roam Research]]
Author: [[ravi-kurani.medium.com]]
Category: #articles
Number of Highlights: ==1==
Last Highlighted: *2021-11-24*
Readwise URL: https://readwise.io/bookreview/13204965
Source URL: https://ravi-kurani.medium.com/how-i-read-20-articles-a-day-using-instapaper-readwise-amazon-kindle-and-roam-research-7aca037a5fc4


# Highlights 
I’m going to give you the flow of how I read, consume information, and log it — and then I’ll break down each section and how I’ve set it up.  ^278320249

