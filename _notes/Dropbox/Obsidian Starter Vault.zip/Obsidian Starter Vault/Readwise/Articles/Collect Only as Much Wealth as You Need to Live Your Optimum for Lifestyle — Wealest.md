# Collect Only as Much Wealth as You Need to Live Your Optimum for Lifestyle — Wealest
#done 

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)
[[ReadWise]]
## Metadata
- Author: [[Thomas Waschenfelder]]
- Full Title: Collect Only as Much Wealth as You Need to Live Your Optimum for Lifestyle — Wealest
- Category: #articles
- URL: https://www.wealest.com/articles/optimum-lifestyle

## Highlights
- Most people get a job to make money, and then design their lifestyle around their job. And many are miserable because of it.
- **Humans aren’t meant to work forty hours and then “live for the weekend.”**
- Leverage has changed the game. You can now design your lifestyle first, and then find the right leveraged career that suits you.
- Here’s entrepreneur Daniel Vassallo advocating for this on Twitter:
  “I want my work to help me design my preferred lifestyle, not my work to dictate what my lifestyle can be… The biggest opportunity cost is enduring a lifestyle you dislike…Thinking about opportunity cost in terms of earning potential is missing the point. If you're enduring an existence you dislike, you're missing out on a lifestyle that matches your true preferences. That's the real opportunity cost.”
- My preferred lifestyle has a lot of free time - for thinking, for walking, for exercise, etc.
- I’m judged on my output, not hours worked.
## New highlights added March 23, 2022 at 5:40 PM
- writing has loads of free time built in. You only have 3-4 hours of solid creativity available per day, so once that’s burned, you’re freed up.
# Collect Only as Much Wealth as You Need to Live Your Optimum for Lifestyle — Wealest

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Thomas Waschenfelder]]
- Full Title: Collect Only as Much Wealth as You Need to Live Your Optimum for Lifestyle — Wealest
- Category: #articles
- URL: https://www.wealest.com/articles/optimum-lifestyle

## Highlights
- Most people get a job to make money, and then design their lifestyle around their job. And many are miserable because of it.
- Humans aren’t meant to work forty hours and then “live for the weekend.”
- Leverage has changed the game. You can now design your lifestyle first, and then find the right leveraged career that suits you.
- Here’s entrepreneur Daniel Vassallo advocating for this on Twitter:
  “I want my work to help me design my preferred lifestyle, not my work to dictate what my lifestyle can be… The biggest opportunity cost is enduring a lifestyle you dislike…Thinking about opportunity cost in terms of earning potential is missing the point. If you're enduring an existence you dislike, you're missing out on a lifestyle that matches your true preferences. That's the real opportunity cost.”
- My preferred lifestyle has a lot of free time - for thinking, for walking, for exercise, etc.
- I’m judged on my output, not hours worked.
- writing has loads of free time built in. You only have 3-4 hours of solid creativity available per day, so once that’s burned, you’re freed up.
