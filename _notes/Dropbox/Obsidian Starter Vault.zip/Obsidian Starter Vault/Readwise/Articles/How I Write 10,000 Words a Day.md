%%
ID: 13222790
Updated: 2022-01-29
%%
![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

# About
Title: [[How I Write 10,000 Words a Day]]
Author: [[Jenn Leach]]
Category: #articles
Number of Highlights: ==12==
Last Highlighted: *2022-01-28*
Readwise URL: https://readwise.io/bookreview/13222790
Source URL: https://millennialnextdoor.medium.com/how-i-write-10-000-words-a-day-98a01c1ba39a


# Highlights 
Is 10,000 words a day really possible for a writer?  ^278698995

---

With the help of tools.One paid tool and one free tool.  ^278698996

---

I want to say that I don’t write 10,000 words every single day but many times I do, and not just for Medium.  ^278698997

---

The Two Writing Tools I Use to Save Time  ^278698998

---

Google Docs. This is a free word processing software that anybody who has access to the internet can use.  ^278698999

---

What I do to churn out a lot of content in a sitting is use the Voice Typing feature.  ^278699000

---

Use it by talking aloud and have Google Docs pick up the words you’re saying to transcribe it to text in the document.  ^278699001

---

It’s one of the best ways to write at a faster pace and of course, you give your fingers a rest from all that typing.  ^278699002

---

I’ve seen many articles floating around Medium lately about Jarvis, the AI writing tool to help you write tens of thousands of words in a sitting  ^278699003

---

Jarvis uses AI to help you produce content faster.  ^278699004

---

They have a bunch of different templates and recipes you can use for whatever you’re writing about, from blog posts, Facebook ads, press releases, etc.  ^278699005

---

I’m all for outsourcing in life if it saves me time and Jarvis is the tool that can help with that.  ^278699006

