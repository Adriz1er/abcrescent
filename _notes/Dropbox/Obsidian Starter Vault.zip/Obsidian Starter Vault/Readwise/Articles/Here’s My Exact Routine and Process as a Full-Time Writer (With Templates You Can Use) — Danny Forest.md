# Here’s My Exact Routine and Process as a Full-Time Writer (With Templates You Can Use) — Danny Forest

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Danny Forest]]
- Full Title: Here’s My Exact Routine and Process as a Full-Time Writer (With Templates You Can Use) — Danny Forest
- Category: #articles
- URL: https://www.dannyforest.com/blog/heres-my-exact-routine-and-process-as-a-full-time-writer-with-templates-you-can-use

## Highlights
- It’s not all about writing
- made a very important decision that’s set to completely change my life: become a full-time writer.
- For all of my professional life, I had been an entrepreneur, a software engineer, and a video game producer.
- I decided to write daily for a month, just so I could improve my written English.
- Most of the articles were subpar (in hindsight), but I’ve improved quite drastically. I kept the habit in 2019 and 2020 and now I’m making it my full-time gig.
- When I tried to figure out what’s next for me, there was only one thing I loved doing, could get paid for, was pretty good at, and that the world needs — good writing.
- Writing is how I’ve consistently generated revenues since 2018. And that was by writing for only an hour a day. And now, with failed businesses and a newborn at my charge, I need more revenue.
# Here’s My Exact Routine and Process as a Full-Time Writer (With Templates You Can Use) — Danny Forest

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Danny Forest]]
- Full Title: Here’s My Exact Routine and Process as a Full-Time Writer (With Templates You Can Use) — Danny Forest
- Category: #articles
- URL: https://www.dannyforest.com/blog/heres-my-exact-routine-and-process-as-a-full-time-writer-with-templates-you-can-use

## Highlights
- It’s not all about writing
- made a very important decision that’s set to completely change my life: become a full-time writer.
- For all of my professional life, I had been an entrepreneur, a software engineer, and a video game producer.
- I decided to write daily for a month, just so I could improve my written English.
- Most of the articles were subpar (in hindsight), but I’ve improved quite drastically. I kept the habit in 2019 and 2020 and now I’m making it my full-time gig.
- When I tried to figure out what’s next for me, there was only one thing I loved doing, could get paid for, was pretty good at, and that the world needs — good writing.
- Writing is how I’ve consistently generated revenues since 2018. And that was by writing for only an hour a day. And now, with failed businesses and a newborn at my charge, I need more revenue.
