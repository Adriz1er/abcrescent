- > If you haven’t read hundreds of books, you are functionally illiterate, and you will be incompetent, because your personal experiences alone aren’t broad enough to sustain you. - **Jim Mattis**



# Book Notes
This is a collection of notes from the books I've read. Once again, these are not perfect. They are not created for you. They are created for aiding my thinking and improving my own understanding. There might be spelling mistakes, lack of links between different ideas.

```dataview
List
From #book 
where contains(status, "Completed")
```


---
>  “I cannot remember the books I've read any more than the meals I have eaten; even so, they have made me.”- **Ralph Waldo Emerson**

#### [[Quotes Worth Reading]]