---
---
**Creator:** Jim Rohn
**Source:** Youtube
**Type:** #litnote 

---
- Positive influence and negative influence can have incredible impact on your life
- But only one will take you where you want to go
- EVERYTHING MATTERS. Sure something matters more than one thing. But everything weighs.
- Ignorance is not the best policy. Finding out is.
- **Three major key questions to ask?**
	- Who am I around?
	- What are they doing to me?
		- What have they got me reading, thinking, talking, feeling, saying. Make a serious study of what they are doing to you.
		- It doesn't hurt to ask>
	- Is that OK?
- Take an objective look.
- Get all the toxic people out of your life.
- Nourishing relationships and toxic relationships
- One energy drainer can spoil your whole life
- Make a list of the major people you are communicating with and ask yourself **What kind of person I am becoming because of this relationship?**
	- Am i becoming better? Do they inspire me, encourge me, stretch me?
	- Birds of feather flock together
	- Walk with the losers and you will end up being a loser
- It's easy to influence shape our life
- Someone's opinion of you don't have to be your reality
- **3 Things needed to be successful**
	- Change your mindset
	- Practice OQP
	- Develop your communication skills
		- Once you open your mouth, you tell the world who you are
- Peer pressure is a powerful form of influence. It is subtle
- You will be the people you are around with
- Consciously develop friendships and social networks
- **Disassociation**
	- There are some people you have to break away from
- **Limited Association**
	- Easy to put time and effort in wrong place
	- Make balance
	- ***Spending major time on minor things-*** *Easy way to remain in mediocrity*
	- Spend major time with major influence and minor time with minor influence
	- Its your life, You can do whatever you want when you want
- Look at your values, priorities, and commitments
- You will move in the direction of people you associate with
- **The friends you have will form as you go**
- **Expanded Association**
	- Spending time with the right people
	- Whatever you have to do, do it
	- spend time with major people
	- Get around the right people
- Pick up your plans from successful plan. Don't pick up plans from unsuccessful people
- You have to be smart enough to say that you have got wrong people
- Find right people to set up a plan for you. Steal it
- **Association on purpose**
- Don't join an easy crowd. Join crowd where demands are hight, expectations are hight, spotlight is on.
## ***Pity a man who has got a favorite restuarant but not a favourtie thinker.*

- Measurable progress and having someone to measure them
- Goals
	- health goals
	- Investment goals
	- Travel goals
	- Gifts and sharing
	- Who meet
	- Skills
	- What would you like to be
	- Power and influence 
	- Education for your children
	- Library with the best of books
	- Fly a glider
	- Own a music library
	- Visit paris
	- Cabin in the mountain
	- A mark you would want to make
	- Something you want to prove

### Strive to become the kind of person that people of quality and substance would want to associate with.

Well read, well disciplined, well cultured and well knowledged. Be attractive.

> Continually weigh your time and association.
