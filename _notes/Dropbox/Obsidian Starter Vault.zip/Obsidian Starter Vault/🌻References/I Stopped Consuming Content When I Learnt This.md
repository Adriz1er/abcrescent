---
---
**Source:** https://medium.com/curious/i-stopped-consuming-content-when-i-learnt-this-b0e02c6c8fc4
**Author:** Shreya Badonia
**Type:** #litnote 
**Topics:** [[Content Creation]][[Creativity]]

----
- Until it’s a personal coach who’s well aware of your current situation and is helping you with a tailor-made approach, you shouldn’t listen to a person who’d telling thousand of other people to do the same. Some due diligence is also required from the readers.
- We fall prey to people who claim to have the secret sauce for success or making a million dollars online.
- Prescriptions work only if you want to be a followerr not innovators.
- People don't build successful companies by reading how others did it.
- You will learn a lot about finance by reading a book on wealth but you will not manifest a million dollars without any work
- You'll not build a successfuls startup but can learn how to take the first step.
- Read not to change your mind and position in life. Read or listen only if you need to for your own work.
- Don't do it because someone tells you to
- You'll have to be responsible for the steps you take and whether those steps will take you where you want to go?