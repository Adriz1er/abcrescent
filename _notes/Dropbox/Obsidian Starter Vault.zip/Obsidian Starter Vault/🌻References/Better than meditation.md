---
---
**Source:** https://betterhumans.pub/better-than-meditation-12532d29f6cd?utm_source=pocket_mylist
**Author:** 
**Type:** #litnote 
**Topics:** [[Writing]] [[Meditation]]

----
- Meditation quite slippery. Its hard to get a good grip of it
- You have two minds. The fast and slow mind. Rational and emotional mind
- Constantly running, telling story about the past and predicting the future.
- the ability to hear, and observe, the inner debate that’s always going on in my head, and to recognize the difference between “me” and all the noise.
- Free writing is better than mediataion somehow.
- Add a word limit and keep writing until you finish what you intend.
- Don't pay attention to anything. just write your thoughts down. 
- Correctness doesn't matter. Writing matters
- Keep writing even if you run out of ideas. Write nonsense even if you have to.
- Just keep the words flowing.
- Feel discomfort?Ask yourself questions and write about that.
- 