---
---
**Creator:** [[Dr. Vivek Bindra]]
**Type:** #litnote 
**Topics:** [[Youtube]] [[Side Hustle]]

---

> Solopreneurship is behaving better than Entrepreneurship.

Any one can teach. There are digital teachers

# Content creation to wealth creation
Content is not king, it's the kingdom.
 Content strategy
 Generate traffic on youtube
 Monetize traffic on private platform
 
Conventional to Exponential

You don't need to be a teacher in this time. All you need is a hobby. Are you a writer? graphic designer? Singer? Artist? Whatever you do, you can monetize through youtube.

- 0-1 Million Subscribers
 - **Know you audience.** 
	 - Find an intersection point of what you know, what you can do, and what the market wants and what you like. Don't just jump in a random trend. Know your audience. Age, income, gender, etc. Find his needs, interest, concern, expectations. NICE Analysis
 
 - **Keep a clear agend on you content.** 
	 - Decide and define on what your outcome is and work towards your purpose
	 - There are three types of speech - the one you prepared, the one you said and the one you want to give. Don't let all of these be different
 - **Give unusual useful information**
	 - Data 
	 - story
	 - Build trust and relationship
	 - Add in amazing sequence
	 - Coherent central message
	 - Inspirational information without repitition
	 - well paced
	 - good timing
	 - More content with less time
	 - Provide value
	 - Don't extempore
		 - Build comfort in the first 30 minutes
		 - Build confidence in teh next 30 minutes
		 - build perfection in the next 30 minutes
		 - Reherse and prepare before you start
	 - **Talk with conviction and confidence**
	 - Being a youtuber is a skill that you learn 
	 - Stay away from mediocrity. Don't serve some mediocrea content to your audience
	 - Enthusiasm is contagious
		 - Audience doesn't care if you are well or not
		 - Always give a speech you would like to hear
	 - Opening and closing speech(strong summary, quotations, data)
	 - Verbal| Visual| Local
		 - Phisology impacts Psychology
		 - Motion impacts emotion
		 - Action impacts perception
	 - Trending content

- Monetization
	- If you have a good personality, you can get money on the name of personality. personality can make you profits
	- Personality+Technology= Scalibility
	- Add right technology
	 