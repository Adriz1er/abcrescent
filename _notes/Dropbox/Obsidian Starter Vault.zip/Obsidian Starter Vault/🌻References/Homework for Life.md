---
---
**Creator:** Tedx Talks
**Source:** https://www.youtube.com/watch?v=x7p329Z8MD0)
**Type:** #litnote 
**Topics:**

---

We all have tiny moments in life. These moments are the ones that mostly connect with the audience. You have to find those small moments in life. 
Everyday before you go to bed ask yourself what is the best story you can tell that happened to you today?
Write down small snippets that describes what happened to you. They can be sentences or even simple words.
If you sit down and honestly look for stories in your life, you began to develop a story telling lens. 

If you do this, you will never lose another day in your life. Because if you do, you will always look forward towards your day to find out what the day will bring that will be different than the next day.

By doing this, you also slow down things. People say "time flies" and they don't remember what happened or they did the last day. 

You won't lose another day in your life because of what you do. If you go back and look today after 3 years, you will be right back in the moment.

It requires commitment and faith to do this and many people will not do it. If you can't give 5 minutes of your life to something that will change your life, I don't know what you will give your time to.

The results may not happen instantly. Therefore, it requires faith to start giving your 5 minutes every day.

If you do it and you change your life, here's the added bonus: You're better than all the people who spent their evenings scrolling through their phone instead of giving 5 minutes to their life.

There's nothing better in life than walking with a confidence that you are better than the rest of the people.