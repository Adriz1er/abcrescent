---
---
**Source:** https://jamesclear.com/great-speeches/how-to-guarantee-a-life-of-misery-by-charlie-munger
**Type:** #litnote 
**Topics:** [[Success]]

----
- Can't tell you how to be happy but could tell from experience on how to gurantee misery
- Ingesting chemicals to alter mood
- Envy
- Resentment
- **Be unreliable**
- **Learn everything you possibly can from your own personal experiences.** Minimize what you can learn from the good and bad experiences of others, living and dead
- There are so many common disasters of mankind. 