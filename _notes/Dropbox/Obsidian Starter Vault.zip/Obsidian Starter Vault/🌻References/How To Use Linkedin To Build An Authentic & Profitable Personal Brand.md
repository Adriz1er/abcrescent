---
---
**Source:** https://bettermarketing.pub/how-to-use-linkedin-to-build-an-authentic-profitable-personal-brand-aa7106c7bf47
**Type:** #litnote 
**Topics:** [[LinkedIn]] 

----
- Know how to position yourself and use linkedin to execute your plan
- **Post regularly- once every day**
- Value consisteny over anything else
- First hour reaction is critical
- **Add vulnerability to your story**
	- Emotional stories increase reach and engagement
- **Experiment with different types of post**
- Interact with other users
- Be consistent with the same type of message