---
---
**Source:** Newsletter substack
**Type:** #litnote #todevelop 

----
- **Brainwash yourself or get brainwashed**
- Don't get angry
	- Anger is a way to give control of your brain to others. Its addictive. Look at the people on social media shouting and aruging with each others. 
	- Don't argue. Choose silence
	- No one can mess with you if you are silent
- Say "fuck No" to 99% of asks
	- Every ask will occupy room in your brain
- Don't wait forever
	- You can get hit by bus today. Stop waiting
- Build a callous around your brain
	- A large biceps makes you physically strong. But your mind is the strongest of all. 
	- Read books. Read psychology.
- Be tightarse with your time
	- Treat every hour of your time like one whole bitcoin

- **Wealth is not being famous**
	- It's owning your time. Doing whatever the hell you want and snoozing until 11 AM if you choose a few hors of the day. 

