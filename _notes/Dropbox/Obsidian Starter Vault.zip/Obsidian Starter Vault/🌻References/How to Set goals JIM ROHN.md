---
---
**Creator: ** Jim Rohn
**Source: **:  (https://www.youtube.com/watch?v=K8l-7iKsnME)
**Type:** #litnoteX
**Topics:** [[Goal Setting]] [[Jim Rohn Goal Setting]]

---

- Have short term goals and long term goals
- Long-range goals are your dreams(without dreams you'll die) FOr the next 3,5,10 or 20 years where do you wanna be, where do you wanna look,
- Short term goals are the goals that you want to accomplish this week, this month or this year. These are confidence builders

There are 3 types of goals
Economic Goals
 Make sure your economics are well planned. Economics is the fundamental if you 
 
Things Goals
Cars, homes, everything that you want  to get.

Personal development goals
 things that you need to do
 
 # Work on your goals
- Make plans.
>  The people who fail to plan, fail to plan

- Write your goals down. Put your goals down on paper
- Check the size of your goals and what kinds of they are
> Your goals affect you all day long. They affect your attitude, the way you talk, walk.

Don't be a follower, be a student. Take advice but don't take orders. Make sure what you do is the product of your own conclusions. Don't do what others say. Take what others say but think about it and then take action.

----

 