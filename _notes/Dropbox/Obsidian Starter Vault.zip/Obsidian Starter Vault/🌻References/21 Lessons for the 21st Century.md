---
title: 21 Lessons for the 21st Century
author: Yuval Noah Harari
category: History
publisher: Random House
publish_date: 2018
total_page: 400
cover_url: "https://books.google.com/books/content?id=FLhPEAAAQBAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: Unfinished
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 525512179
isbn13: 9780525512172
---
**Title:** 21 Lessons for the 21st Century
**Author:** Yuval Noah Harari
**Type:** #litnote #book #todevelop 

---