---
---
**Source:**[https://www.reddit.com/r/BitcoinMarkets/comments/54v3n8/cryptotrading_advice_for_beginners/](https://www.reddit.com/r/BitcoinMarkets/comments/54v3n8/cryptotrading_advice_for_beginners/)
**Type:** #litnote #todevelop 

----
- It's impossible to keep emotions out of your trading when you have to worry about making profits consistently to pay your bills.
- If you can't keep your emotions out, you will lose in trading. You will be a bad trader
- To be successful trader, you don't give shit about emotions. You have a plan and stick to it no matter the market conditions. It's boring.
- If you don't have a trading plan, you will have a hard time keeping your emotions away. 
- ***How to lose in trading?***
	- Average down your losers
	- Trade without stop and profit target
	- Revenge trade
	- Don't have proper entries and exits
	- No risk management
	- Large position sizing