---
---
**Source:** https://writingcooperative.com/9-article-frameworks-i-use-to-repeatedly-get-published-in-fast-company-and-entrepreneur-4ebb0a009b6f
**Author:**
**Type:** #litnote 
**Topics:** [[Writing]] [[Writing Tips]]

----
- Articles are the best ways to share your opinions and ideas. Even with good ideas, organizing our thoughts can be daunting
- Template fix that. **Outlining can fix that problem for you**
- # Listicle
	- Great format to strengethen your writing muslces. Organize thoughts and ideas easily
- # Listicle Variation
	- Give them a cruncy, easy-to-read format and collection of ideas or steps. 
- # The popularity piggyback
	- People want to see the secrets of famous or established people. Seize the opportunity to create that content
	- Have an uninteresting life yourself? This is the best format to create
- # The Expert/ author piggyback
	- Existing expert's content+ specific takeaway 
- # Against the grain opinion
	- Different is better than better
	-  Have a polarizing opinion than an opinion no one cares about.
- # Old tips, new audience
	- What's obvious to you is amazing to others. 
	- Write about a variety of topics for one audience
- # Super-duper step-b-step
	- Write with every small details and you'll see a magnetic response
- # Newsjumping
	- Write if you can form opinions and write quickly before the media outles
- # Self-experimentation
	- Don't have to reinvent the wheel. Just write about the unique experiences. It makes you original