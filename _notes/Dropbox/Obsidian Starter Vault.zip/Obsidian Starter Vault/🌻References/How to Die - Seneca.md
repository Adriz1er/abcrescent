---
title: How to Die
author: Seneca
category: Philosophy
publisher: Princeton University Press
publish_date: 2018
total_page: 256
cover_url: "https://books.google.com/books/content?id=XXGYDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 691175578
isbn13: 9780691175577
---
**Title:** How to Die
**Author:** Seneca
**Type:** #litnote #book #todevelop 

---