---
---

**Source:** https://www.technologyreview.com/2020/09/03/1007716/digital-gardens-let-you-cultivate-your-own-little-bit-of-the-internet/
**Author:**
**Type:** #litnote #todevelop 
**Topics:** [[Digital Garden]]

----
- Digital Gardens are adjusted to slow learning
- Unlike blogs, they are quiet spaces you own
- They don't follow any rules
- You are not talking to a large audience. You are talkling to yourself
- As you learn more about the idea, you can add more and evolve the idea. By engaging in digital gardening, you are finding new connections and new depths to your ideas
- They are usually light-weight with an emphasis on text itself
- It reflects the owner's thinking style
- Choosing the right solution will help you maintaining a sustainable digital garden. Don't let the tool get in the way of actual gardening. 