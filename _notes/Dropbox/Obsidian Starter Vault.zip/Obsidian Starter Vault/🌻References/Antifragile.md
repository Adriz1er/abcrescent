---
title: Antifragile
author: Nassim Nicholas Taleb
category: Business & Economics
publisher: Penguin Books Limited
publish_date: 2013
total_page: 519
cover_url: "https://books.google.com/books/content?id=3vF7kQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 141038225
isbn13: 9780141038223
---
**Title:** Antifragile
**Author:** Nassim Nicholas Taleb
**Type:** #litnote #book #todevelop 

---