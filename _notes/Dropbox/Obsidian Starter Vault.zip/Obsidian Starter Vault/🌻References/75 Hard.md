---
---
**Name:** 
**Speaker:**
**Type:** #litnote 

---
1. No Cheat Meals
	1. Its detoxification of your body
	2. Clean meal
	3. Choose a diet and stick to it
2. Drink 1 Gallon of water everyday
	1. Its harder than most people think
	2. Your physical activity require more water. 
3. Commit to 2- 45 minutes workout: 1 Outside and 1 Inside
	1. Do what you can 
	2. Don't make excuses of weather. conditions doesn't matter. 45 minutes outside no matter what.
	3. Doing things that you don't want to do is the key to be better at what you do. 
4. Read 10 Pages of Non-fiction 
	1. Psychology/ business
	2. Not digital book/ No audio-book
	3. Sense of accomplishment when you move through a book. 
5. Take a Progress picture
	1. Its not just a physical transformation
	2. You forget the little details as you go
	3. You don't have to share online but take photos with shirt off
	4. Its okay to be embarrassed in the beginning

Use common sense. But don't listen to the bitch voice in your head. Don't go out to training when its raining and there's thunderstorm

This is opportunity for you to change your life and the life of people who are in contact with you. 


Developing mental toughness is the best way to be the best version of yourself.




The reason why you are not where you want to be is because you change the plan the way you want.

---
---
After 75 days
### Phase-1
- 5 Power list
- 10 Minutes of Visualization
- 5 Minute Cold Shower
Mandatory 30 day break between phase-1 & Phase-2

### Phase- 2
is same as 75 hard but only for 30 days

### Phase-3 
- should last at the anniversary of your 75 hard challenges
- All of the 5 elements of 75 hard
- cold showers
- Act of kindness
	- Actually making about others
	- Paying for someone else
	- helping someone else
	- Gratitude, volunteering
	- Do good things. Do new good things
	- Think out of the box
	- Give positive and receive positive
- Talk to a stranger
	- Full on conversation not just a hello
	- Forces you to build connection and confidence
	- Talk to 1 people every single day
	- Tremendously valuable exercise for 

If you have to ask, it doesn't count. If you don't have to ask, it counts.