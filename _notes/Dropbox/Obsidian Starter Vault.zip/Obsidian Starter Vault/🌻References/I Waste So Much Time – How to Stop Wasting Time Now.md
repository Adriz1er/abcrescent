---
---
**Source:**[ https://eduardklein.com/life/i-waste-so-much-time/](https://eduardklein.com/life/i-waste-so-much-time/)
**Type:** #litnote  
**Topics:** [[Time Management]] [[Time is Precious]]

----
- Can't find a single person who doesn't walk like a zombie scrolling their phones.
- Internet is to pull you in and demand your attention
- You waste time if you don't plan your day in advance.
- No plan= Gurantee of time waste
- Laziness
	- Inertia. Do something physical to move your body and keep in the inertia of motion
- Poor time management
	- A friend walks up to you and takes half money from purse. But we indulge our time to gossips, memes. because we don't value our time. We don't know what to do with the time.
- Absence of motivaiton
- Distractions
	- you do besides yAnything our task is distraction
- **Time waste is OK**
	- Socializing is good for mental health
	- Don't turn down your friends
	- Maintain a balacne

- Understand why you procrastinate
- Have strategies to prevent procrastination triggers
- Organize your time. Focus on what's important
- Stop wasting time on the internet
	- Regulate your time on social media
	- Schedule internet time
	- Turn off notification
	- Don't take device with you everywhere you go
	- Stay accountable with different apps