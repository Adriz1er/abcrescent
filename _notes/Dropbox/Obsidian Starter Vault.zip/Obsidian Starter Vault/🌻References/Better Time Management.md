---
---
**Creator:** Appblock
**Price:** Free 
**Link:** App block academy
**Type:** #litnote [[Courses]]
**Topics:** [[Time Management]]

---
# Daily Energy
- Your energy fluctuates differently 
- High and increasing when you wake up
- After lunch, it dips. Good time to take nap or do other activities to hype up your energy back
- Plan to avoid unnecssary online time during those periods as much as possible.
- Give rest to your brain before an hour to bed. 
- Learning to monitor your energy will bring significant change in your life.
# To Do Today
- Write all of your tasks
- Split large tasks and combine small tasks
- Each tasks should take around 30-60 minutes
- Batch related tasks to cut the disruption of lfow
- Color code your priorities
- Link your tasks together with arrows. Make the best order with priority. 
- Make time estimates. When you will start and when you will finish
- Focus on one thing only
- Cross it out after finishing time
- Take breaks to restore your energy
- Make it a habit to do previous night.

- Do Important things not the urgent ones
- Create  a sleeping schedule

# Decision Paralysis
- More choices= Less happy
- More choices= harder decisions and postponing them
- Decision paralysis leads to increasing procrastination

# Pomodoro
- Make a list of things you want to do. 
- Set timer for 20-40 minutes
- When session eds take a 5 minutes break
- After 3-4 sessions, take a more extended break

# Procrastination And Why We Do It?
- You procrastinate and do trivial things
- Procrastination is not laziness. 
- They want to do things but can't force themselves to do it.
- People don't regrets the things they have done. People regret the things they haven't done.
- Start tackling procrastination
	- Understand time is your most valuable commodity. You should not waste it
	- Understand that you need to rest and chill but thats not the same as procrastination. 
	- Work on a day-to-day schedule
	- Take baby steps. Meditate and drink a lot of water.
	- The second attempt at anything is easier
 # Deep Work
 - Working in a distraction-free environment that pushes beyond your cognitive capabilitie
 - 3 Mani rules
	 - Environment and rituals: Create rituals and routines that makes things easier and more automatic. The environment should be non-disturbing and silent
	- Embrace boredom: Intense concentration is a skill that you must learn to develop. Take care of your concentration outside of deep work sessions
	- Quit social media: Its shallow living. Just because something offers you benefits doesn't mean its worth  your time.
# Learn to use your flow
- Flow means being fully absorbed. It puts your skills and strength to work.
- The activity will engulf you. Time will stop. 
- It releases dopamine in the long run making us more happier and calmer
- Walk with podcasts in your ear. 
- Flow occurs when you are challenged and put your skills to work