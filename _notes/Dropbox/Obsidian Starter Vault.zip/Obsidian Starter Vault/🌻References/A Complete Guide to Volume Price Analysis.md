---
title: A Complete Guide to Volume Price Analysis
author: Anna Coulling
category: Business & Economics
publisher: CreateSpace
publish_date: 2013
total_page: 171
cover_url: "https://books.google.com/books/content?id=2Li0ngEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 1491249390
isbn13: 9781491249390
---
**Title:** A Complete Guide to Volume Price Analysis
**Author:** Anna Coulling
**Type:** #litnote #book #todevelop 

---