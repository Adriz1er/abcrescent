---
---
**Source:**http://www.paulgraham.com/identity.html
**Type:** #litnote 

----
- People don't need to be experts to have political or religious opinions
- They have strongly hold beliefs
- Everyone is an expert yet they all contradict
- No argument will grow as fast as religion
- Fruiful discussion only if you don't engage your identity
- Religion and politics become a part of peoples identity. 
- You can't think clearly if you have a label for yourself
- You don't need to be an expert to have an opinion. You only need a strong conviction
- To have better arguments, let as few things as possible in your identities.


***The more labels you have, the more dumber they will make.***