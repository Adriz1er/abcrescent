---
---
**Creator:** [[🧔Dr. Yogi Vikasananda]]
**Source:** [यहि हो भयंकर पीडाको सरल औषधि || Dr.Yogi Vikashananda | Manokranti | 2021 - YouTube](https://www.youtube.com/watch?v=Kz-6vWh7xhs)
**Type:** #litnote 
**Topics:** [[Pranayama]] [[Meditation]] 

---

Start step by step. You go to extreme only when the situation demands.

When there's fire in your house, you don't go looking for the door. Your only goal is to get out of the burning house. Jump out of the windows or back door. This might get you serious injury.

But in a normal situation, if you try this, this will not be much help of you. It might even kill you. But in cases you can jump to the stages where you wouldn't normally.

Deep Breathing is the secret to your unknown power.

The more you control your breathe, the more you control your mind.

Because your mind stops when you start breathing.

> Aapat dharma ma j gare pani galat hunna.

---
If you can control your breath, you can control the world.
Inhale, and stop breathing.

