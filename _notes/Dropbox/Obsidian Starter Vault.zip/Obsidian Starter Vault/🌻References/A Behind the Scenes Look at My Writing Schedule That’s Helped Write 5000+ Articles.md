---
---
**Source:** https://writingcooperative.com/a-behind-the-scenes-look-at-my-writing-schedule-thats-helped-write-5000-articles-44a30be51c8e
**Author:** Tim Denning
**Type:** 
**Topics:** [[Writing Tips]]

----
- Most writer quit even before they start. Don't you be the one.
- No writing schedule= No writing career.
- Treat writing like a marathon. 
- Rest in between writing days to recover but sprint when you do.
- Secure your writing schedule. Let no one touch it. 
- Make a write or die attitude so that you can stick to your writing scheule
- Identify the distractions and turn them off.
- Don't edit on the same day. Leave a day or at least half-a-day before your editing sesssion.
- Because task-switching drains your energy
- Research more and more and more
- Writing is only as good as your research.
- Choose the best sources to fill your brain with ideas.
- Stay away from the crappy algorithms
- Take notes and create a second brain
- **Write 10 headlines every single day**
- Map out the headline so that you r writing sounds clear
- Keep headline always on the screen when you write so that you don't drift off the main focus of article
- Collect cool words daily and add them to your writing guide
- Use twitter: Most powerful rapid-feedback tool writers have access to.
- Applaud your fellow writer friends and spread love
- Write to inspire not to brag.
- Build your writing schedule so that you can automate your writing empire.
