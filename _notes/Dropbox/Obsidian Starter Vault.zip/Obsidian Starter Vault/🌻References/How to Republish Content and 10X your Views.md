---
---
**Title:** How To Republish Your Content And 10x Your Views 
**Source:**  https://nicolascole77.medium.com/how-to-republish-your-content-and-10x-your-views-da1a3c52e7f3
**Author:** [[Nicolas Cole]]
**Type:** #litnote 
**Topics:** [[Writing]] [[Content Creation]] 

----
[[Repurpose Content]]
- Write wherever you feel the best. You can always copy/paste across multiple platforms
- Just pick 1 primary platform to publish on.
- Personal blog is not a good choice. Nobody knows it exists.
- Go where your audience is already spending time
- Don't hit publish and vanish away
	- You can get so much more mileage out of your content
	- Go to quora and answer the related questions
	- Go to linkedin and paste the article
- It's your content and you can do whatever you like with it. You can publish and republish it
- It helps you know where your readers are