---
---
**Source:** https://www.reddit.com/r/Daytrading/comments/ni2pp7/how_do_i_create_my_own_trading_strategy/
**Type:** #litnote #todevelop [[Trading]]

----
1. Pick any strategy you find
2. Paper trade at least 100 trades to understand its win rate and optimal RRR
3. Find if you can optimize the strategy in any way
4. If the strategy is profitable, begin trading the strategy with small size and scale up every 2 weeks or month. Stick to the plan without blowing up your account
> A strategy is only as good as the person managing it.

Making money in the market will take time and patience. A first year student doesn't develop a new mathematical law. They first learnd and understand already developed equations before even trying to do that.

> Use strategies that rely on price action, patterns, and volume instead of indicators.

Indicators tell you the same thing price is doing. Don't load your screen with that shit. 


Use 21 Day MA when its a little slopy.

