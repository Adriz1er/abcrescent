---
---
Creator: Filipe Donadio
Source:https://www.youtube.com/watch?v=GUtXbwqS3iQ
Type: #litnote 
Topics:

---


You can use folders, tags and links

# Folders
Folders are primarily used methods of organizing notes. They are helpful in creating a seperation between your notes. But as your notes grow, notes can often be forgotten and it will be hard for you to organize notes everytime in a folder. 
And also you will have to make a quick decision on which folders to put a note on. And sometimes a note may be linked to two or more folders.

# Tags
This is where tags come in use. Unlike folders, you can categorize your notes into multiple topics.
But it will also be visually disorganized when you use tags instead of folders

# Links
Links are also a way to organize notes.

## How to Organize notes
Identify what you want to create about
