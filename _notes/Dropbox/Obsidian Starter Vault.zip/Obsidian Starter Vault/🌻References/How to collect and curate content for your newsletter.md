---
---
**Title:** How to collect and curate content for your newsletter
**Source:** https://freshvanroot.com/blog/2020/how-to-collect-and-curate-content-for-your-newsletter/
**Author:** 
**Type:** #litnote #todevelop 
**Topics:** [[Content Creation]] [[Newsletter]]  [[Creating curated newsletter]]

----

- Newsletter is popular and best for creators
- Content discovery to publishing your newsletter. Tools to intergate into your workflow
- Content creation is on the rise. So much content that's out there. You have a chance to tap in it. 
- Steps in curating content
	- Content Discovery
		- Find interesting topics to read about. Other newsletters, Feedly nuzzel google news.
		- Don't make social media your primary source. 
		- Scan your newsfeed
	- Organize
		- Scan your sources
	- Editing
		- have idea before writing a newsletter. Basic outline of what gets shared
	- Start again and repeat