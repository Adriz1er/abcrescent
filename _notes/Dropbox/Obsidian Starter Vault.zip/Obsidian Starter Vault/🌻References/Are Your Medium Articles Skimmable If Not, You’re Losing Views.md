---
---
**Source:** https://nicolascole77.medium.com/are-your-medium-articles-skimmable-if-not-youre-losing-views-447cc4cb23bf
**Author:**
**Type:** #litnote #todevelop 
**Topics:** [[medium.com]] [[Writing]] [[Content Creation]]

----
- Digital reders skim
- They don't read 
- make snap judgement whethere something is worth their time or not. 
- They look for sections and parts that attract them. And then only they start reading.