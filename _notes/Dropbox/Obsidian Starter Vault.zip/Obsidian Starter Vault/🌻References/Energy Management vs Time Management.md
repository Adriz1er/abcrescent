---
---
**Source:** https://www.coachingpositiveperformance.com/energy-management-vs-time-management/
**Author:**
**Type:** #litnote #todevelop 
**Topics:** [[Time Management]] [[Productivity]] [[Energy Management not Time Management]]

----
To use time effectively, learn energy management.

- Learn what energizes you
- Increase your breaks
- Reward yourself every step 
- Schedule activities you love


Energy is vital. Without energy, you can't get anything done. 

Make sure you rest between your sprints to rebuild the energy levels and maximize your performance.

