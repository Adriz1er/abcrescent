---
---
**Creator:** FinPort
**Source:** https://youtu.be/MGglyvc8d58
**Type:** #litnote #todevelop 
---

- **Fundamentals:** Finding the true value 
- **Technicals:** Finding the turning points in the markets to take advantage of 
- Fundamental and technicals are not enough
- If you are so sure the market is going up or down? Why don't you bet all of your wealth? Lets fasten the wealth assimilation process
- Don't trade like its flipping a coin
- This is a game to play without fear and hesitation.

## Being a consistently winning trader
- Money you make = F(Hit rate, Risk/reward ratio)
- 4 Fears of traders
	- Being wrong
	- Losing money
	- Missing out
	- Leaving money on the table
- Your edge is a mixture of hit-rate, RR, and commissions
- Don't be a different person after every other trades. Don't be euphoric or fearful
- Trade with consistency. Trade with the same mindset and mentality.
- You just need one pattern to make money from the market. Don't need to read everything. Falling wedges and head and shoulders.
- ***Most people go bankrupt because they risk too much in a single trade***
- **MONEY MANAGEMENT IS THE KEY**
- You need discipline
- **To build discipline, you need to grit your teeth, and stick to the process.**
- To build a habit, you will have to grit your teeth. And all of sudden you will develop neural pathways between your ears
- Sticking to the rules for first few trades is difficult but it becomes easy after on. 
- **Get a written plan with no more than one page**
- You are only few trades away from being a trainer. 
- Get over your first 8 trades.
- You don't require discipline afterwards. You build that neural pathway.






































