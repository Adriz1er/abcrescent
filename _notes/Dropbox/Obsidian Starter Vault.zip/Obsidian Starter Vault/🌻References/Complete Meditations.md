---
---
Source: (https://www.youtube.com/watch?v=UmKN_DEE4nE&list=PLPronQREsCKRyctL6naSG3F2RdtDO4fkX&index=2&ab_channel=ManokrantiCentre)
Type: #litnote 
Tag: [[Meditation]] 

# Meditation
It is completely normal to have thoughts and in the inital level of meditation
Thoughts come in the mind of every individual.
- You should not try to restrict your thoughts, because the more you try, the more they will attack
- Accept your thoughts  and don't try to control it
- The first step of meditation is to control your  body. Think of your body as a vessel and thoughts as water. If you move your body, your thoughts will spill over. Byt if you control your body, you will able to control your thoughts

## How to start
- Sit in a upright posture and take any mudra
- Now focus on your breath. Don't breath purposly. Just notice how you breath. How each breath is going through your nose. Feel the breath going through your nose. Feel the cold when it goes in and the warmth when it comes out.
- Give numbering to each breath and count up to 10 and repeat

## What are the signs of being meditations
- Chemicals release in your brain causing you to feel immense pleasure.
- You don't feel like moving your body anymore. You can embrace more pain than ever
- If you feel this, then you have entered the first level of meditation
- Even if mosquito is sitting in your forearm and sucking you, you won't feel like moving it away
----

- You are not disturbed by the sound of vehicles your notifications, and any outside surrounding

--- 
- 1st level: 
	- Count your breath as you inhale and exhale. Count to 10 and restart. Still atleast for 10 minutes. After you master this level, move to next level.
- 2nd level: 
	- Notice how you are breathing and follow it without giving numbers. From the gut to the nose. Inhale and exhale and as you go do this. You are doing meditation now, you have to be in meditative stage.
- 3rd level: 
	- The deeper you go in the meditative stage, the slower you breathe. This is not something you do, this is something that happens.

----