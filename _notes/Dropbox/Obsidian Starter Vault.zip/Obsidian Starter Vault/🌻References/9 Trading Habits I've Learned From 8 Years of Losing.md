---
---
**Creator:** Day Trading Addict
**Source:** ](https://www.youtube.com/watch?v=NQcsjldJmjo&ab_channel=DayTradingAddict)
**Type:** #litnote 
**Topics:** [[Trading]]

---

# Find What Makes You Angry
- If you are angry with your trades, you will do revenge trade. You might even blow up your account


# Don't Rush
- Give time. Treat trading like a business. Don't try to skip. 
- You will take time to learn about the markets

# Learn about the market structures
- Breakout, reverse, Range
- Either trade them or don't trade them. 
- Don't trade when you are at the end of structures

# Trade on Demo Longer
- If demo doesn't tell you are ready, you are not. 
- Your results will show you when you are ready

# Not Giving Up
- Why do you trade?
- Don't quit. Stay longer in the game. You'll make money ultimately

# Take Screenshots of Your Trade
Make sure why you are losing trades.

# Accept losing
- You will have more losing trades than winning. You can't beat yourself up
- Don't beat for your losers
- Trading is about multiple trades
# Invest in education
- Don't try to build something from scratch
- Learn from someone else who has done something
# Stick to one strategy
- Stay with one strategy and become good atit
- Every strategy works but not always
- Understand the strategy before you do it.


