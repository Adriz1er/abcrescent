---
---
**Creator:** Karen Foo
**Source:** https://youtu.be/lu-CqBtH0gw
**Type:** #litnote 
**Topics:** [[Trading]]

---


- Trading signals are not much important
# Risk Management
- Risk management is boring. Its not exciting to put in only $100 dollars when you have an account of $1000. You want to risk it all
- Leverage is only fine if you are a seasoned trader


# Focus on the bigger picture
- What drives country market
- The sentiment of people, whats actually happening 
- Stop only looking for technical analysis.
- Focus on fundamentals too. The overall macroeconomics
- Add fundaental analysis in your trading
- Understand the political, economic condition of the market
- Paul Trudor Jonas- 40-50% win ratio

# Focus on risk to reward ration than win ratio

# Switch to higher time frames
- Only scalp or day trade only if you are experienced
# Having a Mentor

# Comparing with other markets

# Understanding the Market Sentiment



# Backtest, Plan and Journal


