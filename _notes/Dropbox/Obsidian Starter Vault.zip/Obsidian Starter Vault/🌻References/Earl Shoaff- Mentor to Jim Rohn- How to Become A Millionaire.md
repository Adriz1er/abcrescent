---
---

**Creator:** Earl Shoaff
**Source:**
**Type:** #litnote #todevelop 
**Topics:** [[Success]] [[Money]] 

---

Some people are aware, some are not but still using them. We are governed by the basic laws of the universe and they work for you if you know how to apply them in your life.

It doesn't matter if you are good or bad, if you use these principles properly can radically change your life. These are the laws of success, laws of poverty, laws of prosperity, laws of hate, laws of peace, laws of peace.

If we use them rightfully, wonderful things will happen to us. If you use them wrong, you will land in trouble.
 
You can have anything you want in this world and you can be anything you want to be if you follow these rules.

# Plant seeds
We are farmers. You will sow what you reap. If you plant a watermelon seed, you are not getting radishes. If you want radishes, you must plant radishes. And if you plant the seeds on the earth, you must plan it properly. If you don't plant properly, you won't be able to harvest it properly.

Planting a seed on the earth is basically the same process you use in the mental world. 

- You need to learn to define your goals
- Visualize. If your visualization is stronger, it's more likely you will achieve the goal
- We are creators. Everything that happened in your life is exactly how you designed it. Don't blame others for people you attracted.
- Learn to describe things. You can have everything wonderful happening to you.

# Imagination. Make your visualization stronger. 
# Be specific and be as detailed as you can. Pinpoint what you want to do.
# Put it in a paper. Write it down and put it away. Put it in your sub-conscious
# Give more of what you want to receive
 If you don't want others to talk about you, you have to stop talking about others. If you want to stop receiving hate, you have to stop giving it out. Whatever you give, you receive more of it.