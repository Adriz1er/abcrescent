---
---
**Creator:** Bhavin Desai
**Source:** youtube
**Type:** #litnote 
**Topics:** [[Sprituality]] 

---
Jangle ki sobha jhadi se
nari ki sobha sari se
Rogi ki sobha nadi se
aur
Mard ki sobha mucu or dadi se

--- 
Fall asleep within 1 minutes
Be fresh within 2 minutes

Don;t let mal stop your body and don't let the man stop your brain.

Who was a will, he has a way. 

----
Sugar will enter your bones. More than 5000 diseases occur as a result of this.

Every animal sleeps on their stomach. Lay on your stomach. and hit your ass  with your legs

Head right legs left with both attached together /