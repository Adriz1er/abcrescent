---
---
**Source:**  https://medium.com/the-brave-writer/david-perells-three-plates-of-ideas-e2888fcc1f69
**Author:** Kjell Vandevyvere
**Type:** #litnote #todevelop 
**Topics:** [[Writing]]

----
- No one will read your blog posts at the beginning.
- You can't lure anyone in
- David perells 3 plates of ideas are:
	- **Sample**
		- They give your audiencethe taste of what you do
		- Fastest way to reach your audience
		- Try different ideas
		- Engage with bigger accounts if your follower count is low
		- Be consistent with your samples
		- It's like giving peopel food in the streets
		- Many people will come. If they like they will come again
	- **Appetizers**
		- They are short articles people can share
		- atomic essays
		- Takes time and effort to create them.
	- **Main course**
		- Long-form essays
		- It's risky to cook main course in the beginning. THe ROI is considerably lower than samples 
- You have to diversify you content. Don't just always share the samething. Take samples from main course or appetizers and share those in your social media feeds