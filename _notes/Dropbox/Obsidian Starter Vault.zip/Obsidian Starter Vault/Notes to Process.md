---
cssClasses: cards 
---

```dataview 
TABLE file.ctime as "Created" 
FROM #todevelop and -#book
Limit 20
```
