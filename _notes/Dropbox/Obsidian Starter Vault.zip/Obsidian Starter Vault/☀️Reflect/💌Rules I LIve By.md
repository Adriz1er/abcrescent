## Never Sleep Without Living The Next Day
## Never Begin The Before You Have Lived It
## Raise Your Awareness
## Be Uncomfortable in Small Ways
## Be Independent
## Produce Something Before You Consume Anything
## Don't Spend 5 Minutes Worrying About a Thing If It Doesn't Matter In The Next 5 Years
## Follow The Great Book
# This is Good