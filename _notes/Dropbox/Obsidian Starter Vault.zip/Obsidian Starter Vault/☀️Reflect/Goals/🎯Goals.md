---

kanban-plugin: basic

---

## Content Creation

- [ ] [[Publish 100 Articles on Medium]]


## Personal Development

- [ ] [[Read 80 Books]]
- [ ] [[75 Hard Challenge]]


## Wealth

- [ ] [[Make $5000 Online]]


## Mental

- [ ] [[100 Disciplined Trades]]




%% kanban:settings
```
{"kanban-plugin":"basic","metadata-keys":[{"metadataKey":"Progress","label":"","shouldHideLabel":false,"containsMarkdown":false},{"metadataKey":"Target","label":"","shouldHideLabel":false,"containsMarkdown":false},{"metadataKey":"Timespan","label":"","shouldHideLabel":false,"containsMarkdown":true},{"metadataKey":"Reason","label":"","shouldHideLabel":false,"containsMarkdown":true},{"metadataKey":"Bar","label":"","shouldHideLabel":true,"containsMarkdown":true},{"metadataKey":"Projects","label":"","shouldHideLabel":true,"containsMarkdown":true}]}
```
%%