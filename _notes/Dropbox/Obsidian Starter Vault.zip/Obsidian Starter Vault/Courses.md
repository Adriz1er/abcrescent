These are the course I've taken. Some, I've completed while others left in the middle. These notes include the highlights of the course I've taken. 

As I've already said, you might not understand a lot of these notes completely because they are not written for you. The are written to aid me in my thinking, remembering and getting the most out of these courses. 

However, I hope some of these notes might add value to your life.

```dataview
List 
From "🌻References" and ([[Courses]])
```
